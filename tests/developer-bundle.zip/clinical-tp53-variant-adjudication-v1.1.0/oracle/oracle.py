#!/usr/bin/env python3
"""Reference Oracle for the TP53 functional-adjudication pilot.

This is a reproducibility oracle, not a clinical decision-support tool.

Three outputs are kept strictly distinct and must never be collapsed:

  1. `protein_assay_label`  - the standardized eight-promoter yeast-assay bin,
     recomputed here from the supplied measurements.
  2. `overall_functional_phenotype` - a provisional case-level evidence
     adjudication, read from the frozen answer key, never derived from (1).
  3. `clinical_pathogenicity` - out of scope for this benchmark; always
     `not_assessed`.

The Oracle is offline and deterministic: it opens no sockets, reads no clock,
and emits output in a fixed, sorted order so repeated runs are byte-identical.
"""
from __future__ import annotations

import argparse
import json
import math
import statistics
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "data" / "task_input.json"
KEY = ROOT / "oracle" / "reference_answers.json"

PROMOTERS = ["WAF1", "MDM2", "BAX", "H1433s", "AIP1", "GADD45", "NOXA", "P53R2"]

# Thresholds transcribed from the NCI TP53 Database User Manual (SRC-002),
# TransactivationClass column: median of the 8 promoter-specific activities,
# non-functional <=20, partially functional >20 and <=75, functional >75 and
# <=140, supertrans >140.
EXPECTED_THRESHOLDS = {
    "functionally_abnormal": {"median_lte_pct_wt": 20},
    "mixed_or_context_dependent": {"median_gt_pct_wt": 20, "median_lte_pct_wt": 75},
    "functionally_preserved": {"median_gt_pct_wt": 75, "median_lte_pct_wt": 140},
    "supertrans_subclass": {"median_gt_pct_wt": 140},
    "missing_panel": "indeterminate",
}

ALLOWED_LABELS = {
    "functionally_abnormal",
    "functionally_preserved",
    "mixed_or_context_dependent",
    "indeterminate",
}
ALLOWED_DNE = {"Yes", "Moderate", "No", "NA", "Not reported", "Indeterminate"}
ALLOWED_DNE_LOF = {"DNE_LOF", "notDNE_notLOF", "notDNE_LOF", "unclass", "NA", "Indeterminate"}
ALLOWED_POLYMORPHISM = {"Yes", "No"}

KEY_REQUIRED_FIELDS = {
    "case_id",
    "median_pct_wt",
    "protein_assay_label",
    "overall_functional_phenotype",
    "nci_dne_class",
    "nci_dne_lof_class",
    "validated_polymorphism",
    "clinical_pathogenicity",
    "required_evidence_ids",
    "reference_rationale",
    "assay_label_status",
    "overall_label_status",
}

MEDIAN_TOL = 1e-9


class OracleError(ValueError):
    """Raised for any condition that must stop reference generation."""


def panel_label(median):
    """Map an eight-promoter median (% of wild-type activity) to the assay bin.

    The >140% branch is written out explicitly rather than folded into the
    preceding branch. The NCI manual calls that range `supertrans`, a distinct
    source category; this project's submission contract has only four labels, so
    supertrans is mapped to `functionally_preserved`. The mapping is retained
    because supertrans describes activity at or above wild-type level - the panel
    does not show impaired transactivation - so the mapping asserts nothing the
    measurement contradicts. The information loss is real and is recorded by
    `panel_subclass()` and in `validation/known_limitations.md`.

    No case in the current 11-case cohort has a median >140%, so this branch is
    exercised only by unit tests.
    """
    if median is None:
        return "indeterminate"
    if median <= 20:
        return "functionally_abnormal"
    if median <= 75:
        return "mixed_or_context_dependent"
    if median <= 140:
        return "functionally_preserved"
    return "functionally_preserved"  # supertrans per SRC-002; see panel_subclass()


def panel_subclass(median):
    """Source-vocabulary subclass retained alongside the four-label schema."""
    if median is None:
        return "none"
    return "supertrans" if median > 140 else "none"


def compute_median(case_id, measurements):
    """Independently recompute the eight-promoter median, validating as we go."""
    if not isinstance(measurements, dict):
        raise OracleError(f"{case_id}: measurements_pct_wt must be an object")
    if set(measurements) != set(PROMOTERS):
        missing = sorted(set(PROMOTERS) - set(measurements))
        extra = sorted(set(measurements) - set(PROMOTERS))
        raise OracleError(
            f"{case_id}: expected exactly the eight named promoters; "
            f"missing={missing}, unexpected={extra}"
        )
    values = []
    for promoter in PROMOTERS:
        raw = measurements[promoter]
        if isinstance(raw, bool) or not isinstance(raw, (int, float)):
            raise OracleError(
                f"{case_id}/{promoter}: measurement must be a JSON number, got {raw!r}"
            )
        value = float(raw)
        if not math.isfinite(value):
            raise OracleError(f"{case_id}/{promoter}: non-finite activity value")
        if value < 0:
            raise OracleError(f"{case_id}/{promoter}: negative activity value {value}")
        values.append(value)
    return statistics.median(values)


def load_json(path):
    with Path(path).open(encoding="utf-8") as handle:
        return json.load(handle)


def build_reference(input_doc, key_doc):
    """Deterministically build the reference submission, or raise OracleError."""
    if input_doc.get("thresholds") != EXPECTED_THRESHOLDS:
        raise OracleError("Task-input thresholds do not match the documented NCI Kato-assay bins")
    if key_doc.get("benchmark_version") != input_doc.get("benchmark_version"):
        raise OracleError(
            "Input and answer key benchmark versions differ: "
            f"{input_doc.get('benchmark_version')!r} vs {key_doc.get('benchmark_version')!r}"
        )
    if input_doc.get("expected_promoters") != PROMOTERS:
        raise OracleError("Task-input expected_promoters does not match the frozen promoter panel")

    key_cases = key_doc.get("cases")
    if not isinstance(key_cases, list) or not key_cases:
        raise OracleError("Answer key contains no cases")
    key_by_id = {case["case_id"]: case for case in key_cases}
    if len(key_by_id) != len(key_cases):
        raise OracleError("Duplicate case_id in answer key")

    known_sources = {source["source_id"] for source in input_doc.get("source_registry", [])}
    if not known_sources:
        raise OracleError("Task input has an empty source_registry")

    results = []
    seen = set()
    for case in input_doc["cases"]:
        case_id = case["case_id"]
        if case_id in seen:
            raise OracleError(f"Duplicate case_id in input: {case_id}")
        seen.add(case_id)

        median = compute_median(case_id, case["primary_assay"]["measurements_pct_wt"])

        # Guard the scientific boundary: the standardized median must come from
        # the yeast panel only, never pooled with another cell system.
        cell_system = case["primary_assay"].get("cell_system")
        if cell_system != "yeast":
            raise OracleError(
                f"{case_id}: standardized panel must be the yeast assay, "
                f"found cell_system={cell_system!r}"
            )

        key = key_by_id.get(case_id)
        if key is None:
            raise OracleError(f"No adjudication key for {case_id}")
        missing_fields = KEY_REQUIRED_FIELDS - set(key)
        if missing_fields:
            raise OracleError(f"{case_id}: answer key missing fields {sorted(missing_fields)}")

        # Never silently trust a stored median; recompute and compare.
        stored_median = key["median_pct_wt"]
        if isinstance(stored_median, bool) or not isinstance(stored_median, (int, float)):
            raise OracleError(f"{case_id}: key median must be a number")
        if abs(float(stored_median) - median) > MEDIAN_TOL:
            raise OracleError(
                f"{case_id}: key median {stored_median} disagrees with the value recomputed "
                f"from the supplied measurements ({median})"
            )

        computed_label = panel_label(median)
        if key["protein_assay_label"] not in ALLOWED_LABELS:
            raise OracleError(
                f"{case_id}: unsupported protein_assay_label {key['protein_assay_label']!r}"
            )
        if computed_label != key["protein_assay_label"]:
            raise OracleError(
                f"{case_id}: key assay label {key['protein_assay_label']!r} disagrees with the "
                f"threshold rule applied to median {median} ({computed_label!r})"
            )
        if key["overall_functional_phenotype"] not in ALLOWED_LABELS:
            raise OracleError(
                f"{case_id}: unsupported overall_functional_phenotype "
                f"{key['overall_functional_phenotype']!r}"
            )
        if key["clinical_pathogenicity"] != "not_assessed":
            raise OracleError(
                f"{case_id}: clinical_pathogenicity is out of scope and must be 'not_assessed'"
            )

        annotations = case["source_annotations"]
        for field, allowed in (
            ("nci_dne_class", ALLOWED_DNE),
            ("nci_dne_lof_class", ALLOWED_DNE_LOF),
            ("validated_polymorphism", ALLOWED_POLYMORPHISM),
        ):
            if annotations.get(field) not in allowed:
                raise OracleError(
                    f"{case_id}: task-input {field}={annotations.get(field)!r} is not an allowed value"
                )
            if key.get(field) != annotations.get(field):
                raise OracleError(
                    f"{case_id}: answer-key {field}={key.get(field)!r} does not match the "
                    f"task-input source annotation {annotations.get(field)!r}"
                )

        evidence_ids = key["required_evidence_ids"]
        if not isinstance(evidence_ids, list) or not evidence_ids:
            raise OracleError(f"{case_id}: required_evidence_ids must be a non-empty list")
        if len(set(evidence_ids)) != len(evidence_ids):
            raise OracleError(f"{case_id}: duplicate entries in required_evidence_ids")
        unknown = sorted(set(evidence_ids) - known_sources)
        if unknown:
            raise OracleError(f"{case_id}: required_evidence_ids reference unknown sources {unknown}")
        case_sources = set(case["provenance"]["source_ids"])
        not_declared = sorted(set(evidence_ids) - case_sources)
        if not_declared:
            raise OracleError(
                f"{case_id}: required_evidence_ids {not_declared} are not declared in this "
                "case's provenance"
            )

        rationale = key["reference_rationale"]
        if not isinstance(rationale, str) or len(rationale.strip()) < 35:
            raise OracleError(f"{case_id}: reference_rationale is missing or too short")

        results.append(
            {
                "case_id": case_id,
                "median_pct_wt": round(median, 6),
                "protein_assay_label": computed_label,
                "overall_functional_phenotype": key["overall_functional_phenotype"],
                "nci_dne_class": annotations["nci_dne_class"],
                "nci_dne_lof_class": annotations["nci_dne_lof_class"],
                "validated_polymorphism": annotations["validated_polymorphism"],
                "clinical_pathogenicity": "not_assessed",
                "evidence_ids": sorted(evidence_ids),
                "rationale": rationale + " Evidence: " + ", ".join(sorted(evidence_ids)) + ".",
                "confidence": {
                    "assay": "high_for_transcribed_panel_values",
                    "overall": "provisional_requires_second_review",
                },
            }
        )

    if set(key_by_id) != seen:
        key_only = sorted(set(key_by_id) - seen)
        input_only = sorted(seen - set(key_by_id))
        raise OracleError(f"Input/key case mismatch; key-only={key_only}, input-only={input_only}")

    # Sort by case_id so output order never depends on input file ordering.
    results.sort(key=lambda case: case["case_id"])
    return {
        "benchmark_id": input_doc["benchmark_id"],
        "benchmark_version": input_doc["benchmark_version"],
        "status": "provisional_curated_pilot_not_expert_panel_gold_standard",
        "clinical_pathogenicity": "not_assessed",
        "cases": results,
    }


def main():
    parser = argparse.ArgumentParser(description="Generate the reference submission.")
    parser.add_argument("--input", type=Path, default=INPUT)
    parser.add_argument("--key", type=Path, default=KEY)
    parser.add_argument("--output", type=Path, help="Output JSON path; default stdout")
    args = parser.parse_args()
    try:
        result = build_reference(load_json(args.input), load_json(args.key))
    except Exception as exc:  # noqa: BLE001 - surfaced verbatim to the operator
        print(f"ORACLE_ERROR: {exc}", file=sys.stderr)
        return 2
    rendered = json.dumps(result, indent=2, ensure_ascii=False) + "\n"
    if args.output:
        args.output.write_text(rendered, encoding="utf-8")
        print(f"Wrote {len(result['cases'])} reference cases to {args.output}")
    else:
        print(rendered, end="")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
