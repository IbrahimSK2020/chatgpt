#!/usr/bin/env python3
"""Minimal, dependency-free validator for the JSON Schema subset used by this project.

Rationale
---------
The repository ships JSON Schema documents, but before v1.1.0 nothing in the test
suite or the verifier actually executed them, so the schemas were documentation
rather than an enforced contract. Adding `jsonschema` as a dependency was rejected
because the project's stated design goal is a standard-library-only, offline,
deterministic build.

This module therefore implements exactly the keywords used by
`schemas/submission.schema.json` and `schemas/task_input.schema.json`:

    type, const, enum, required, additionalProperties (bool),
    properties, items, minItems, maxItems, uniqueItems,
    minLength, minimum

Any schema keyword encountered that is not in the supported set raises
`UnsupportedSchema`. Failing loudly is deliberate: silently ignoring an unknown
keyword would let a schema appear to pass while a real constraint went unchecked.
"""
from __future__ import annotations

import json
from pathlib import Path

SUPPORTED = {
    "$schema", "title", "description", "type", "const", "enum", "required",
    "additionalProperties", "properties", "items", "minItems", "maxItems",
    "uniqueItems", "minLength", "minimum",
}

TYPES = {
    "object": dict,
    "array": list,
    "string": str,
    "number": (int, float),
    "integer": int,
    "boolean": bool,
    "null": type(None),
}


class UnsupportedSchema(Exception):
    """Raised when the schema uses a keyword this validator does not implement."""


def _type_ok(value, expected: str) -> bool:
    # JSON booleans are Python bools, which are ints; never accept them as numbers.
    if expected in ("number", "integer") and isinstance(value, bool):
        return False
    return isinstance(value, TYPES[expected])


def validate(instance, schema, path: str = "$") -> list[str]:
    """Return a list of human-readable validation errors (empty list == valid)."""
    errors: list[str] = []
    unsupported = set(schema) - SUPPORTED
    if unsupported:
        raise UnsupportedSchema(f"{path}: unsupported schema keywords {sorted(unsupported)}")

    if "type" in schema:
        expected = schema["type"]
        if expected not in TYPES:
            raise UnsupportedSchema(f"{path}: unknown type {expected!r}")
        if not _type_ok(instance, expected):
            errors.append(f"{path}: expected type {expected}, got {type(instance).__name__}")
            return errors  # further keyword checks would be meaningless

    if "const" in schema and instance != schema["const"]:
        errors.append(f"{path}: expected const {schema['const']!r}, got {instance!r}")

    if "enum" in schema and instance not in schema["enum"]:
        errors.append(f"{path}: {instance!r} is not one of {schema['enum']}")

    if isinstance(instance, str):
        if "minLength" in schema and len(instance) < schema["minLength"]:
            errors.append(f"{path}: shorter than minLength {schema['minLength']}")

    if isinstance(instance, (int, float)) and not isinstance(instance, bool):
        if "minimum" in schema and instance < schema["minimum"]:
            errors.append(f"{path}: {instance} is below minimum {schema['minimum']}")

    if isinstance(instance, dict):
        for key in schema.get("required", []):
            if key not in instance:
                errors.append(f"{path}: missing required property {key!r}")
        props = schema.get("properties", {})
        if schema.get("additionalProperties") is False:
            for key in instance:
                if key not in props:
                    errors.append(f"{path}: additional property {key!r} is not allowed")
        for key, subschema in props.items():
            if key in instance:
                errors.extend(validate(instance[key], subschema, f"{path}.{key}"))

    if isinstance(instance, list):
        if "minItems" in schema and len(instance) < schema["minItems"]:
            errors.append(f"{path}: has {len(instance)} items, minItems is {schema['minItems']}")
        if "maxItems" in schema and len(instance) > schema["maxItems"]:
            errors.append(f"{path}: has {len(instance)} items, maxItems is {schema['maxItems']}")
        if schema.get("uniqueItems") is True:
            seen: list = []
            for item in instance:
                if item in seen:
                    errors.append(f"{path}: duplicate item {item!r} violates uniqueItems")
                    break
                seen.append(item)
        if "items" in schema:
            for i, item in enumerate(instance):
                errors.extend(validate(item, schema["items"], f"{path}[{i}]"))

    return errors


def validate_file(instance_path, schema_path) -> list[str]:
    instance = json.loads(Path(instance_path).read_text(encoding="utf-8"))
    schema = json.loads(Path(schema_path).read_text(encoding="utf-8"))
    return validate(instance, schema)


if __name__ == "__main__":
    import sys

    if len(sys.argv) != 3:
        print("usage: schema_check.py <instance.json> <schema.json>", file=sys.stderr)
        raise SystemExit(2)
    problems = validate_file(sys.argv[1], sys.argv[2])
    for problem in problems:
        print(problem)
    print("VALID" if not problems else f"INVALID ({len(problems)} errors)")
    raise SystemExit(0 if not problems else 1)
