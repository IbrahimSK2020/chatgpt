#!/usr/bin/env python3
"""Independent verifier and scorer for the TP53 functional-adjudication pilot.

Independence contract
---------------------
This module does not import, subclass, or otherwise reuse any Oracle code. The
promoter list, the threshold rule, and the median computation are written out
again here. A regression test (`tests/test_verifier.py::test_verifier_does_not_
import_oracle`) asserts that `oracle` never appears in `sys.modules` after this
module is imported, so the independence claim is enforced rather than asserted.

Integrity gating
----------------
Objective label points are *gated*, not merely reduced. A submission that
invents evidence identifiers, misreports NCI source annotations, or asserts a
clinical pathogenicity claim forfeits all credit for that case even when its
labels happen to match the key. A model that guesses the right bin while
fabricating its provenance has not done the task.

What this program cannot do
---------------------------
It cannot establish that free-text reasoning is biologically correct, and it
cannot establish that the frozen key is scientifically right. It checks
structure, arithmetic, provenance and scope against a key that is explicitly
labelled provisional.
"""
from __future__ import annotations

import argparse
import json
import math
import statistics
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from schema_check import validate as schema_validate  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "data" / "task_input.json"
KEY = ROOT / "oracle" / "reference_answers.json"
SUBMISSION_SCHEMA = ROOT / "schemas" / "submission.schema.json"

LABELS = {
    "functionally_abnormal",
    "functionally_preserved",
    "mixed_or_context_dependent",
    "indeterminate",
}
DNE = {"Yes", "Moderate", "No", "NA", "Not reported", "Indeterminate"}
DNE_LOF = {"DNE_LOF", "notDNE_notLOF", "notDNE_LOF", "unclass", "NA", "Indeterminate"}
POLYMORPHISM = {"Yes", "No"}

# Independently restated, not imported from the Oracle.
PROMOTERS = ["WAF1", "MDM2", "BAX", "H1433s", "AIP1", "GADD45", "NOXA", "P53R2"]
TOL = 1e-4

TOP_REQUIRED = {"benchmark_version", "clinical_pathogenicity", "cases"}
TOP_ALLOWED = TOP_REQUIRED | {"benchmark_id", "status"}
CASE_REQUIRED = {
    "case_id", "median_pct_wt", "protein_assay_label", "overall_functional_phenotype",
    "nci_dne_class", "nci_dne_lof_class", "validated_polymorphism", "clinical_pathogenicity",
    "evidence_ids", "rationale", "confidence",
}
CASE_ALLOWED = CASE_REQUIRED

EXPECTED_THRESHOLDS = {
    "functionally_abnormal": {"median_lte_pct_wt": 20},
    "mixed_or_context_dependent": {"median_gt_pct_wt": 20, "median_lte_pct_wt": 75},
    "functionally_preserved": {"median_gt_pct_wt": 75, "median_lte_pct_wt": 140},
    "supertrans_subclass": {"median_gt_pct_wt": 140},
    "missing_panel": "indeterminate",
}

POINTS = {
    "panel_label": 30,
    "overall_label": 30,
    "median": 15,
    "source_annotations": 5,
    "evidence": 10,
    "clinical_boundary": 5,
    "rationale_shape": 5,
}
# Failing any of these means the case scores zero, regardless of label agreement.
GATING = ("evidence", "source_annotations", "clinical_boundary")

LIMITATIONS = [
    "A PASS means structural, arithmetic, provenance and scope checks succeeded "
    "against a key that is explicitly provisional. It is not evidence of biological "
    "truth or of expert consensus.",
    "Free-text rationale is checked for length and for citation of the required "
    "evidence identifiers only. Semantic correctness of the reasoning is not "
    "verified and requires qualified human review.",
    "The rationale check can be satisfied by string-stuffing evidence identifiers "
    "into otherwise empty prose. Minimum-token and identifier-density heuristics "
    "raise the cost of that, but do not eliminate it.",
    "The overall_functional_phenotype component scores agreement with a single-curator "
    "provisional adjudication. Disagreement with it is not proof of error.",
    "Bulk-source reconciliation against the official NCI R21 download is NOT complete; "
    "see validation/known_limitations.md and validation/bulk_reconciliation.csv.",
]


def load(path):
    with Path(path).open(encoding="utf-8") as handle:
        return json.load(handle)


def independent_median(measurements):
    """Recompute the panel median from task input, independently of the Oracle."""
    if not isinstance(measurements, dict) or set(measurements) != set(PROMOTERS):
        raise ValueError("source panel must contain exactly the eight expected named promoters")
    values = []
    for promoter in PROMOTERS:
        raw = measurements[promoter]
        if isinstance(raw, bool) or not isinstance(raw, (int, float)):
            raise ValueError(f"{promoter}: measurement must be a number")
        value = float(raw)
        if not math.isfinite(value) or value < 0:
            raise ValueError(f"{promoter}: measurements must be finite and non-negative")
        values.append(value)
    return statistics.median(values)


def expected_panel_label(median):
    """Threshold rule restated independently of the Oracle (SRC-002)."""
    if median is None:
        return "indeterminate"
    if median <= 20:
        return "functionally_abnormal"
    if median <= 75:
        return "mixed_or_context_dependent"
    return "functionally_preserved"  # includes the supertrans range, >140


def add_error(errors, case_id, field, message):
    errors.append({"case_id": case_id, "field": field, "error": message})


def verify(submission, input_doc, key_doc, schema=None):
    errors: list[dict] = []
    if not isinstance(submission, dict):
        return {
            "status": "FAIL", "score": 0.0, "max_score": 100,
            "errors": [{"case_id": "__root__", "field": "root",
                        "error": "submission must be a JSON object"}],
            "score_breakdown_by_case": {}, "limitations": LIMITATIONS,
        }

    # --- Declared schema contract, actually executed -------------------------
    schema_errors: list[str] = []
    if schema is not None:
        schema_errors = schema_validate(submission, schema)
        for problem in schema_errors:
            add_error(errors, "__root__", "json_schema", problem)

    # --- Top-level structure -------------------------------------------------
    extra_top = set(submission) - TOP_ALLOWED
    missing_top = TOP_REQUIRED - set(submission)
    if extra_top:
        add_error(errors, "__root__", "schema", f"unexpected top-level fields: {sorted(extra_top)}")
    if missing_top:
        add_error(errors, "__root__", "schema", f"missing required top-level fields: {sorted(missing_top)}")
    if submission.get("benchmark_version") != input_doc.get("benchmark_version"):
        add_error(errors, "__root__", "benchmark_version", "missing or incorrect benchmark_version")
    if "benchmark_id" in submission and submission.get("benchmark_id") != input_doc.get("benchmark_id"):
        add_error(errors, "__root__", "benchmark_id", "incorrect benchmark_id")
    if "status" in submission and submission.get("status") != \
            "provisional_curated_pilot_not_expert_panel_gold_standard":
        add_error(errors, "__root__", "status", "unexpected status string")
    submission_scope_ok = submission.get("clinical_pathogenicity") == "not_assessed"
    if not submission_scope_ok:
        add_error(errors, "__root__", "clinical_pathogenicity",
                  "must be exactly 'not_assessed'; this benchmark does not classify clinical pathogenicity")
    if input_doc.get("thresholds") != EXPECTED_THRESHOLDS:
        add_error(errors, "__input__", "thresholds",
                  "task input thresholds differ from the documented assay thresholds")

    candidate_cases = submission.get("cases")
    if not isinstance(candidate_cases, list):
        add_error(errors, "__root__", "cases", "must be a list")
        candidate_cases = []

    input_by = {case["case_id"]: case for case in input_doc["cases"]}
    key_by = {case["case_id"]: case for case in key_doc["cases"]}
    cand_by: dict = {}
    coverage_valid = True
    for index, case in enumerate(candidate_cases):
        if not isinstance(case, dict):
            add_error(errors, f"row-{index}", "case", "each cases element must be an object")
            continue
        case_id = case.get("case_id")
        if not isinstance(case_id, str):
            add_error(errors, f"row-{index}", "case_id", "must be a string")
            continue
        if case_id in cand_by:
            add_error(errors, case_id, "case_id", "duplicate case_id")
            coverage_valid = False
        else:
            cand_by[case_id] = case
        if case_id not in input_by:
            add_error(errors, case_id, "case_id", "unknown case_id")
            coverage_valid = False
        missing_fields = CASE_REQUIRED - set(case)
        extra_fields = set(case) - CASE_ALLOWED
        if missing_fields:
            add_error(errors, case_id, "schema", f"missing fields: {sorted(missing_fields)}")
        if extra_fields:
            add_error(errors, case_id, "schema", f"unexpected fields: {sorted(extra_fields)}")

    if len(candidate_cases) != len(input_by):
        add_error(errors, "__root__", "case_count",
                  f"expected exactly {len(input_by)} cases, received {len(candidate_cases)}")
        coverage_valid = False
    for case_id in sorted(set(input_by) - set(cand_by)):
        add_error(errors, case_id, "case_id", "missing required case")
        coverage_valid = False

    points_possible = max(1, len(input_by) * sum(POINTS.values()))
    points_earned = 0
    per_case: dict = {}
    known_source_ids = {source["source_id"] for source in input_doc.get("source_registry", [])}

    for case_id, inp in sorted(input_by.items()):
        candidate = cand_by.get(case_id)
        key = key_by.get(case_id)
        breakdown = {component: 0 for component in POINTS}
        breakdown["gated_to_zero"] = False
        if not isinstance(candidate, dict) or key is None:
            per_case[case_id] = breakdown
            continue

        # --- Standardized panel label ---------------------------------------
        panel = candidate.get("protein_assay_label")
        if panel not in LABELS:
            add_error(errors, case_id, "protein_assay_label", "invalid or missing label")
        elif panel == key["protein_assay_label"]:
            breakdown["panel_label"] = POINTS["panel_label"]
        else:
            add_error(errors, case_id, "protein_assay_label",
                      f"expected {key['protein_assay_label']}, received {panel}")

        # --- Overall functional phenotype (distinct from the panel bin) ------
        overall = candidate.get("overall_functional_phenotype")
        if overall not in LABELS:
            add_error(errors, case_id, "overall_functional_phenotype", "invalid or missing label")
        elif overall == key["overall_functional_phenotype"]:
            breakdown["overall_label"] = POINTS["overall_label"]
        else:
            add_error(errors, case_id, "overall_functional_phenotype",
                      f"expected provisional reference {key['overall_functional_phenotype']}, "
                      f"received {overall}")

        # --- Median, recomputed from task input ------------------------------
        try:
            median = independent_median(inp["primary_assay"]["measurements_pct_wt"])
            submitted = candidate.get("median_pct_wt")
            numeric = (isinstance(submitted, (int, float)) and not isinstance(submitted, bool)
                       and math.isfinite(float(submitted)))
            if numeric and abs(float(submitted) - median) <= TOL:
                breakdown["median"] = POINTS["median"]
            else:
                add_error(errors, case_id, "median_pct_wt",
                          f"must equal the independently recomputed median {median:.6f} "
                          f"within tolerance {TOL}")
            if panel in LABELS and panel != expected_panel_label(median):
                add_error(errors, case_id, "protein_assay_label",
                          "submitted assay label is inconsistent with the threshold rule applied "
                          "to the independently recomputed median")
            if abs(float(key["median_pct_wt"]) - median) > TOL:
                add_error(errors, case_id, "reference_key",
                          "frozen reference median disagrees with task input; "
                          "stop evaluation and investigate")
        except (TypeError, ValueError, KeyError) as exc:
            add_error(errors, case_id, "median_pct_wt", f"invalid source measurements: {exc}")

        # --- Source annotations must be copied, never inferred ---------------
        annotations = inp["source_annotations"]
        dne = candidate.get("nci_dne_class")
        dne_lof = candidate.get("nci_dne_lof_class")
        polymorphism = candidate.get("validated_polymorphism")
        if dne not in DNE:
            add_error(errors, case_id, "nci_dne_class", "invalid or missing enum")
        if dne_lof not in DNE_LOF:
            add_error(errors, case_id, "nci_dne_lof_class", "invalid or missing enum")
        if polymorphism not in POLYMORPHISM:
            add_error(errors, case_id, "validated_polymorphism", "invalid or missing enum")
        if (dne == annotations["nci_dne_class"]
                and dne_lof == annotations["nci_dne_lof_class"]
                and polymorphism == annotations["validated_polymorphism"]):
            breakdown["source_annotations"] = POINTS["source_annotations"]
        else:
            add_error(errors, case_id, "source_annotations",
                      "NCI annotations must be reproduced exactly from the supplied evidence "
                      "packet; do not infer them from the assay median or hotspot status")

        # --- Evidence provenance ---------------------------------------------
        supplied = candidate.get("evidence_ids")
        required = set(key["required_evidence_ids"])
        if (isinstance(supplied, list) and all(isinstance(x, str) for x in supplied)
                and len(supplied) == len(set(supplied))
                and required.issubset(set(supplied))
                and set(supplied).issubset(known_source_ids)):
            breakdown["evidence"] = POINTS["evidence"]
        else:
            detail = "must be unique known source IDs and include " + str(sorted(required))
            if isinstance(supplied, list):
                invented = sorted(set(x for x in supplied if isinstance(x, str)) - known_source_ids)
                if invented:
                    detail += f"; invented identifiers not in the source registry: {invented}"
            add_error(errors, case_id, "evidence_ids", detail)

        # --- Clinical scope boundary -----------------------------------------
        if candidate.get("clinical_pathogenicity") == "not_assessed":
            breakdown["clinical_boundary"] = POINTS["clinical_boundary"]
        else:
            add_error(errors, case_id, "clinical_pathogenicity", "must be 'not_assessed'")

        # --- Rationale shape ---------------------------------------------------
        rationale = candidate.get("rationale")
        if isinstance(rationale, str):
            stripped = rationale.strip()
            words = [w for w in stripped.split() if w not in required]
            cites_all = all(source_id in stripped for source_id in required)
            if len(stripped) >= 35 and cites_all and len(words) >= 8:
                breakdown["rationale_shape"] = POINTS["rationale_shape"]
            elif not cites_all:
                add_error(errors, case_id, "rationale",
                          f"must cite each required evidence ID {sorted(required)}")
            else:
                add_error(errors, case_id, "rationale",
                          "must be at least 35 characters and contain at least 8 words beyond "
                          "the evidence identifiers; semantic validity requires human review")
        else:
            add_error(errors, case_id, "rationale", "missing or non-string rationale")

        # --- Confidence, reported separately for assay vs overall -------------
        confidence = candidate.get("confidence")
        if not isinstance(confidence, dict) or set(confidence) != {"assay", "overall"}:
            add_error(errors, case_id, "confidence", "must contain exactly assay and overall fields")
        else:
            if confidence.get("assay") not in {
                    "high_for_transcribed_panel_values", "moderate", "low", "indeterminate"}:
                add_error(errors, case_id, "confidence.assay", "invalid or missing enum")
            if confidence.get("overall") not in {
                    "provisional_requires_second_review", "moderate", "low", "indeterminate"}:
                add_error(errors, case_id, "confidence.overall", "invalid or missing enum")

        # --- Integrity gate ----------------------------------------------------
        # Provenance and clinical-scope failures void the case. A correct label
        # obtained alongside invented evidence is not a correct answer.
        if any(breakdown[component] == 0 for component in GATING) or not submission_scope_ok:
            if any(value for key_name, value in breakdown.items() if key_name != "gated_to_zero"):
                add_error(errors, case_id, "integrity_gate",
                          "case scored zero: evidence provenance, source annotation, or clinical-scope "
                          "requirements were violated, so label agreement earns no credit")
            for component in POINTS:
                breakdown[component] = 0
            breakdown["gated_to_zero"] = True

        per_case[case_id] = breakdown
        points_earned += sum(value for name, value in breakdown.items() if name != "gated_to_zero")

    raw_score = round(points_earned / points_possible * 100, 2)
    # The contract is "exactly one case object per supplied case_id". A submission
    # that duplicates or invents cases has not met it, and must not be reported
    # with a high score just because the expected cases happened to score well.
    if not coverage_valid:
        add_error(errors, "__root__", "coverage_gate",
                  "case coverage is invalid (missing, duplicated, or unknown case_id); "
                  "reported score is zeroed regardless of per-case points")
        score = 0.0
    else:
        score = raw_score
    status = "PASS" if (score == 100.0 and not errors and coverage_valid) else "FAIL"
    return {
        "status": status,
        "score": score,
        "max_score": 100,
        "raw_points_score": raw_score,
        "coverage_valid": coverage_valid,
        "points_earned": points_earned,
        "points_possible": points_possible,
        "case_count_expected": len(input_by),
        "case_count_submitted": len(candidate_cases),
        "schema_validated": schema is not None,
        "schema_error_count": len(schema_errors),
        "errors": errors,
        "score_breakdown_by_case": per_case,
        "limitations": LIMITATIONS,
        "interpretation": (
            "Automated verification covers structure, arithmetic, provenance and scope only. "
            "It cannot establish the scientific validity of free-text reasoning, and it cannot "
            "establish that the provisional reference key is correct."
        ),
    }


def main():
    parser = argparse.ArgumentParser(description="Verify a candidate submission.")
    parser.add_argument("submission", type=Path, help="Candidate JSON submission")
    parser.add_argument("--input", type=Path, default=INPUT)
    parser.add_argument("--key", type=Path, default=KEY)
    parser.add_argument("--schema", type=Path, default=SUBMISSION_SCHEMA)
    parser.add_argument("--report", type=Path, help="Optional report output path")
    args = parser.parse_args()
    try:
        schema = load(args.schema) if args.schema and Path(args.schema).exists() else None
        report = verify(load(args.submission), load(args.input), load(args.key), schema)
    except Exception as exc:  # noqa: BLE001 - malformed JSON must not crash the runner
        report = {
            "status": "FAIL", "score": 0.0, "max_score": 100,
            "errors": [{"case_id": "__root__", "field": "runtime", "error": str(exc)}],
            "score_breakdown_by_case": {}, "limitations": LIMITATIONS,
        }
    rendered = json.dumps(report, indent=2, ensure_ascii=False) + "\n"
    if args.report:
        args.report.write_text(rendered, encoding="utf-8")
    print(rendered, end="")
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
