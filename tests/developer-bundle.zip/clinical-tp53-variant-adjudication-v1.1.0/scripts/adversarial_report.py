#!/usr/bin/env python3
"""Run the verifier against a battery of deliberately incorrect submissions.

Prints what the verifier catches and what it does not, so that the limits of
automated checking stay visible rather than implied. Every row except the
baseline must report FAIL.
"""
from __future__ import annotations

import copy
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "verifier"))
from verify import load, verify  # noqa: E402

INPUT = load(ROOT / "data/task_input.json")
KEY = load(ROOT / "oracle/reference_answers.json")
SCHEMA = load(ROOT / "schemas/submission.schema.json")
REFERENCE = load(ROOT / "oracle/reference_submission.json")


def mutate(fn):
    candidate = copy.deepcopy(REFERENCE)
    fn(candidate)
    return candidate


def stuff(case):
    case["rationale"] = "SRC-002 SRC-004 SRC-005 " * 4


CASES = [
    ("baseline reference (expect PASS)", lambda x: None),
    ("malformed: cases not a list", lambda x: x.update(cases={"a": 1})),
    ("missing case", lambda x: x["cases"].pop()),
    ("duplicate case", lambda x: x["cases"].append(copy.deepcopy(x["cases"][0]))),
    ("extra unknown case",
     lambda x: x["cases"].append(dict(copy.deepcopy(x["cases"][0]), case_id="TP53-999"))),
    ("incorrect median",
     lambda x: x["cases"][0].update(median_pct_wt=x["cases"][0]["median_pct_wt"] + 2)),
    ("threshold-boundary error (69.0 called preserved)",
     lambda x: x["cases"][6].update(protein_assay_label="functionally_preserved")),
    ("swapped overall label",
     lambda x: x["cases"][0].update(overall_functional_phenotype="functionally_preserved")),
    ("overall collapsed into panel label (splice case)",
     lambda x: [c.update(overall_functional_phenotype=c["protein_assay_label"]) for c in x["cases"]]),
    ("invented evidence identifier", lambda x: x["cases"][0]["evidence_ids"].append("SRC-FAKE")),
    ("incorrect source annotation", lambda x: x["cases"][0].update(nci_dne_class="No")),
    ("clinical pathogenicity asserted (top level)",
     lambda x: x.update(clinical_pathogenicity="pathogenic")),
    ("clinical pathogenicity asserted (one case)",
     lambda x: x["cases"][0].update(clinical_pathogenicity="pathogenic")),
    ("inadequate rationale", lambda x: x["cases"][0].update(rationale="Looks abnormal.")),
    ("identifier-stuffed rationale", lambda x: stuff(x["cases"][0])),
    ("extra ACMG field smuggled in", lambda x: x["cases"][0].update(acmg_classification="PS3")),
]


def main():
    header = f"{'adversarial case':50}{'status':8}{'score':>7}{'raw':>8}{'gated':>7}  first error field"
    print(header)
    print("-" * len(header))
    failures = 0
    for name, fn in CASES:
        report = verify(mutate(fn), INPUT, KEY, SCHEMA)
        gated = sum(1 for b in report["score_breakdown_by_case"].values()
                    if b.get("gated_to_zero"))
        first = report["errors"][0]["field"] if report["errors"] else "-"
        print(f"{name:50}{report['status']:8}{report['score']:>7}"
              f"{report.get('raw_points_score', 0):>8}{gated:>7}  {first}")
        if report["status"] == "FAIL":
            failures += 1
    print(f"\n{failures} of {len(CASES) - 1} adversarial submissions were rejected "
          f"(baseline excluded).")
    print("\nLimitations this battery does NOT cover:")
    print("  - prose that cites the right identifiers but reasons incorrectly")
    print("  - a label that matches the key while the key itself is wrong")
    print("  - any error originating upstream in the unreconciled source data (D-04)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
