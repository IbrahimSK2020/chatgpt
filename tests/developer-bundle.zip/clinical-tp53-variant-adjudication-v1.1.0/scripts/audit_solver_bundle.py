#!/usr/bin/env python3
"""Audit a solver archive for answer-key leakage and ZIP integrity.

Checks performed:
  1. ZIP integrity (`testzip`) and absence of path traversal / absolute members.
  2. No forbidden file is present (oracle, verifier, tests, curation, validation).
  3. No gold-label field name appears in any member's bytes.
  4. No case-level overall adjudication label can be recovered: for every case in
     the developer answer key, the archive must not contain a string pairing that
     case_id with its overall_functional_phenotype.
  5. The task input inside the archive carries no gold-label fields.

Exit code 0 means every check passed. Any failure exits non-zero and prints the
specific finding, so this is usable as a release gate in CI.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
KEY = ROOT / "oracle" / "reference_answers.json"

FORBIDDEN_SUBSTRINGS = (
    "oracle/", "verifier/", "tests/", "curation/", "validation/",
    "reference_answers", "reference_submission", "decision_log",
    "source_reconciliation", "human_review_rubric",
)

# Tokens that exist only inside the answer key or curation material. Output field
# names such as `overall_functional_phenotype` are deliberately NOT listed: the
# solver has to be told the shape of the submission it must produce, so those
# names appear legitimately in `schemas/submission.schema.json` and
# `instruction.md`. Flagging them would make this audit fire on every build and
# train the operator to ignore it.
GOLD_FIELD_TOKENS = (
    b"reference_rationale",
    b"required_evidence_ids",
    b"overall_label_status",
    b"assay_label_status",
    b"key_status",
    b"recomputed_panel_label",
)

LABEL_VALUES = {
    "functionally_abnormal",
    "functionally_preserved",
    "mixed_or_context_dependent",
    "indeterminate",
}

# Bytes either side of a case_id occurrence searched for that case's gold label
# in non-JSON members. Chosen to span a typical table row or paragraph.
PROXIMITY_WINDOW = 400


def _objects(node):
    """Yield every dict nested anywhere inside a parsed JSON document."""
    if isinstance(node, dict):
        yield node
        for value in node.values():
            yield from _objects(value)
    elif isinstance(node, list):
        for item in node:
            yield from _objects(item)


def _structural_leak(blob: bytes, case_id: str, overall: str):
    """True if any single JSON object pairs this case_id with its gold label.

    Whole-file matching is too coarse: `data/task_input.json` legitimately
    contains both the case identifiers and - in its `thresholds` block - the
    label vocabulary, with no association between them. Only a co-occurrence
    inside one object actually discloses an answer.
    """
    try:
        doc = json.loads(blob.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return None  # not JSON; caller falls back to proximity matching
    for obj in _objects(doc):
        values = {v for v in obj.values() if isinstance(v, str)}
        if case_id in values and overall in values:
            return True
    return False


def _proximity_leak(blob: bytes, case_id: str, overall: str) -> bool:
    """True if the gold label appears near a case_id mention in free text."""
    text = blob.decode("utf-8", errors="ignore")
    needle = case_id
    start = text.find(needle)
    while start != -1:
        window = text[max(0, start - PROXIMITY_WINDOW): start + PROXIMITY_WINDOW]
        if overall in window:
            return True
        start = text.find(needle, start + 1)
    return False


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def audit(archive_path: Path) -> list[str]:
    findings: list[str] = []
    with zipfile.ZipFile(archive_path) as archive:
        bad = archive.testzip()
        if bad is not None:
            findings.append(f"ZIP integrity failure in member: {bad}")

        names = archive.namelist()
        for name in names:
            if name.startswith("/") or ".." in Path(name).parts:
                findings.append(f"unsafe archive member path: {name}")
            tail = name.split("/", 1)[1] if "/" in name else name
            for token in FORBIDDEN_SUBSTRINGS:
                if token in tail:
                    findings.append(f"forbidden path component {token!r} in member {name}")

        blobs = {name: archive.read(name) for name in names}

    for name, blob in blobs.items():
        for token in GOLD_FIELD_TOKENS:
            if token in blob:
                findings.append(f"gold-label field {token.decode()!r} found inside {name}")

    # Pairwise leak check: a case_id must never be associated with its gold label.
    if KEY.exists():
        key = json.loads(KEY.read_text(encoding="utf-8"))
        for case in key["cases"]:
            case_id = case["case_id"]
            for field in ("overall_functional_phenotype", "protein_assay_label"):
                label = case[field]
                if label not in LABEL_VALUES:
                    findings.append(f"answer key has unexpected label value {label!r}")
                for name, blob in blobs.items():
                    structural = _structural_leak(blob, case_id, label)
                    leaked = structural if structural is not None else _proximity_leak(
                        blob, case_id, label)
                    if leaked:
                        findings.append(
                            f"possible answer leak: {case_id} is associated with its {field} "
                            f"in {name}")
    else:
        findings.append("answer key not found; pairwise leak check could not run")

    # The task input inside the archive must itself be label-free.
    for name, blob in blobs.items():
        if name.endswith("data/task_input.json"):
            doc = json.loads(blob.decode("utf-8"))
            forbidden = {"protein_assay_label", "overall_functional_phenotype",
                         "reference_rationale", "adjudication_rationale", "median_pct_wt"}
            for case in doc["cases"]:
                present = forbidden.intersection(case)
                if present:
                    findings.append(f"{name}: case {case['case_id']} exposes {sorted(present)}")
    return findings


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("archive", type=Path)
    args = parser.parse_args()
    if not args.archive.exists():
        print(f"AUDIT_ERROR: {args.archive} does not exist", file=sys.stderr)
        return 2
    print(f"archive : {args.archive.name}")
    print(f"bytes   : {args.archive.stat().st_size}")
    print(f"sha256  : {sha256(args.archive)}")
    with zipfile.ZipFile(args.archive) as archive:
        print(f"members : {len(archive.namelist())}")
        for name in sorted(archive.namelist()):
            print(f"  - {name}")
    findings = audit(args.archive)
    if findings:
        print(f"\nRESULT: FAIL ({len(findings)} findings)")
        for finding in findings:
            print(f"  ! {finding}")
        return 1
    print("\nRESULT: PASS - no answer-key leakage detected, ZIP integrity verified")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
