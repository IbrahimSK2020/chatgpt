#!/usr/bin/env python3
"""Build the solver-only and developer packages, deterministically.

The pre-1.1.0 builder rewrote `README_solver.md` as a side effect of packaging,
so the repository contents depended on whether the packaging script had been run.
That is removed: this script only reads the working tree and writes ZIPs.

Determinism: every member is written with a fixed timestamp (1980-01-01, the ZIP
epoch) and fixed external attributes, and members are added in sorted order, so
two runs over an unchanged tree produce byte-identical archives.

This script is a packaging convenience, not a security boundary. Always run
`scripts/audit_solver_bundle.py` against the produced archive before release.
"""
from __future__ import annotations

import argparse
import hashlib
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FIXED_DATE = (1980, 1, 1, 0, 0, 0)

# Files a task-solving agent is allowed to see.
SOLVER_INCLUDE = [
    "README_solver.md",
    "instruction.md",
    "data/task_input.json",
    "data/source_manifest.csv",
    "schemas/submission.schema.json",
    "schemas/task_input.schema.json",
    "docs/submission_template.json",
    "LICENSE_AND_ATTRIBUTION.md",
]

# Paths that must never enter the solver archive.
SOLVER_FORBIDDEN_PREFIXES = ("oracle/", "verifier/", "tests/", "curation/", "validation/", "scripts/")
SOLVER_FORBIDDEN_FILES = (
    "docs/reference_submission_example.json",
    "docs/human_review_rubric.md",
    "data/source_reconciliation.csv",
    "data/promoter_activities.csv",
    "README.md",
    "CHANGELOG.md",
)

DEV_EXCLUDE_SUFFIXES = (".pyc",)
DEV_EXCLUDE_DIRS = {"__pycache__", ".git"}


def iter_repo_files():
    for path in sorted(ROOT.rglob("*")):
        if not path.is_file():
            continue
        if any(part in DEV_EXCLUDE_DIRS for part in path.parts):
            continue
        if path.suffix in DEV_EXCLUDE_SUFFIXES:
            continue
        rel = path.relative_to(ROOT).as_posix()
        if rel.endswith(".zip"):
            continue
        yield rel, path


def write_zip(out_path: Path, members: list[tuple[str, Path]], root_name: str):
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out_path, "w", zipfile.ZIP_DEFLATED) as archive:
        for rel, path in sorted(members):
            info = zipfile.ZipInfo(f"{root_name}/{rel}", date_time=FIXED_DATE)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o644 << 16
            archive.writestr(info, path.read_bytes())
    return out_path


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(65536), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--outdir", type=Path, default=ROOT.parent / "dist")
    parser.add_argument("--version", default="1.1.0")
    args = parser.parse_args()

    base = f"clinical-tp53-variant-adjudication-v{args.version}"

    missing = [rel for rel in SOLVER_INCLUDE if not (ROOT / rel).exists()]
    if missing:
        raise SystemExit(f"BUILD_ERROR: solver include list references missing files: {missing}")
    solver_members = [(rel, ROOT / rel) for rel in SOLVER_INCLUDE]

    for rel, _ in solver_members:
        if rel.startswith(SOLVER_FORBIDDEN_PREFIXES) or rel in SOLVER_FORBIDDEN_FILES:
            raise SystemExit(f"BUILD_ERROR: {rel} is on the solver deny list but is in the include list")

    solver_zip = write_zip(args.outdir / f"{base}-solver-only.zip", solver_members, f"{base}-solver")
    dev_zip = write_zip(args.outdir / f"{base}-developer.zip", list(iter_repo_files()), base)

    for path in (solver_zip, dev_zip):
        print(f"{path.name}  bytes={path.stat().st_size}  sha256={sha256(path)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
