# Initial adjudication and source reconciliation log — v0.1.1

## Reconciliation scope

All 11 cases were checked against their official NCI TP53 variant-detail pages. The eight promoter-specific values shown on those pages were compared against the curated measurement rows; medians and primary assay bins were then recomputed from the curated values. The official NCI user manual documents the Kato thresholds: non-functional <=20% WT, partially functional >20 to <=75%, functional >75 to <=140%, and supertrans >140%.

This is a per-variant-detail-page reconciliation, **not** a checksum-level reconciliation against the full bulk R21 CSV download. The bulk file must still be downloaded and checksummed before external benchmark release.

## Corrections from v0.1.0

1. **TP53-008 p.R156C:** corrected cDNA from the erroneous `c.465_466delinsTT` to the official `c.466C>T`; corrected the NCI source URL from `mut_id=20288` to `mut_id=1811`. The official page confirms p.R156C and the eight measurements.
2. **TP53-011 p.V31I:** the initial pilot incorrectly said the standardized eight-promoter panel was absent. The official NCI page contains all eight values. Added them (103.7, 113.5, 104.0, 129.2, 90.6, 75.6, 170.4, 130.1), recomputed median 108.75% WT, and recorded the NCI class `functional`. The overall phenotype remains `mixed_or_context_dependent` because the same NCI record separately summarizes partial WAF1/MDM2 activity and retained BAX activity in another assay context.
3. **Panel count:** updated from 10 to 11 complete panels and from 80 to 88 promoter measurements.

## Recomputed case decisions

- **TP53-001 p.R175H:** median 9.15% WT; assay label functionally abnormal; NCI class non-functional; DNE Yes; DNE_LOF.
- **TP53-002 p.R248Q:** median 0% WT; functionally abnormal; NCI class non-functional; DNE Yes; DNE_LOF.
- **TP53-003 p.R273H:** median 0% WT; functionally abnormal; NCI class non-functional; DNE Yes; DNE_LOF.
- **TP53-004 p.R282W:** median 0% WT; functionally abnormal; NCI class non-functional; DNE Moderate; DNE_LOF.
- **TP53-005 p.G245S:** median 0% WT; functionally abnormal; NCI class non-functional; DNE Yes; DNE_LOF.
- **TP53-006 p.Y220C:** median 2.25% WT; functionally abnormal; NCI class non-functional; DNE Moderate; DNE_LOF.
- **TP53-007 p.R337H:** median 69.0% WT; mixed/partial; NCI class partially functional; DNE Moderate; DNE_LOF category notDNE_notLOF. Keep these distinct assay annotations separate.
- **TP53-008 p.R156C:** median 62.7% WT; mixed/partial; NCI class partially functional; promoter-specific variation includes NOXA 162.8% WT.
- **TP53-009 p.P72R:** median 93.6% WT; recomputed panel bin functionally preserved. NCI TransactivationClass is NA for this validated polymorphism; the recomputation is explicitly project-derived.
- **TP53-010 p.G187S:** median 78.7% WT; protein-only panel bin functionally preserved; overall impact indeterminate due to a broken consensus splice-donor site and SpliceAI donor-gain score 0.56 in the NCI record.
- **TP53-011 p.V31I:** median 108.75% WT; NCI class functional; DNE is NA and DNE/LOF category is notDNE_notLOF. Overall label mixed/context-dependent because other assay evidence reports partial WAF1/MDM2 activity and retained BAX activity.

## Review limitations

This is still a single-curator provisional adjudication, not a two-person expert-reviewed gold standard. A qualified second reviewer must independently re-transcribe source values, check the bulk R21 data file, and adjudicate the overall phenotype labels.
