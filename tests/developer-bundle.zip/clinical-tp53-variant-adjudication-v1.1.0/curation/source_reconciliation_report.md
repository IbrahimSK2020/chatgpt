> **v1.1.0 status note (2026-10-23).** Everything below is the prior curator's
> record from v0.1.1. It was **not re-executed** in the v1.1.0 audit: the NCI
> variant-detail pages are unreachable from the build environment, so the
> page-level reconciliation claimed here is neither confirmed nor contradicted
> by this build. It must not be counted as verification performed by v1.1.0.
> What v1.1.0 *did* verify against an official source is the Kato threshold rule
> and the bulk filename/column layout, from the NCI User Manual. See
> `validation/source_access_blocker.md`, `validation/discrepancy_log.md` and
> `FINAL_REPORT.md` §4.

# Source reconciliation report — v0.1.1

**Audit date:** 2026-10-22  
**Authoritative source:** NCI TP53 Database R21 variant-detail pages, accessed via the official NCI TP53 website.  
**Manual thresholds reference:** https://tp53.cancer.gov/help (Kato assay bins documented in the NCI User Manual).

## Outcome

- 11 of 11 variant identities checked against their official NCI variant-detail pages.
- 11 of 11 cases now have all eight yeast transactivation values represented in the curated measurement table.
- 88 of 88 individual promoter values checked against the official variant-detail page displays.
- All medians recomputed from the 88 values; see `data/source_reconciliation.csv`.
- One wrong variant notation/source URL was corrected (p.R156C).
- One previously omitted full panel was added (p.V31I).
- The standardized yeast panel label and overall functional phenotype remain separate fields.

## Limits of this reconciliation

This release records a manual, case-by-case comparison against the official NCI variant-detail pages, not a checksum-level reconciliation against the downloadable bulk `FunctionIshiokaDownload_r21.csv` file. The bulk file was not captured in the current environment; its retrieval, checksum, and exact row-by-row comparison remain required before the data can be called fully source-file reconciled or expert-reviewed gold truth.

## Interpretation safeguards

- The eight-promoter median is an assay-specific result, not clinical pathogenicity.
- NCI's own user manual warns that other functional assays differ by constructs, response elements, cell systems, and experimental designs; results from distinct assay contexts are not pooled.
- DNE and DNE/LOF categories are retained as source annotations, not inferred from the transactivation median.
- The overall phenotype adjudication remains provisional and requires independent human review.
