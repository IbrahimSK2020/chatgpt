# Curation criteria and adjudication rules

## A. Primary assay endpoint

The primary endpoint is the median of the eight promoter-specific transactivation measurements from the NCI TP53 database's Kato et al. systematic yeast assay record: WAF1, MDM2, BAX, H1433s, AIP1, GADD45, NOXA, and P53R2. Measurements are percent of wild-type activity.

- `functionally_abnormal`: median <= 20% WT.
- `mixed_or_context_dependent`: median > 20% and <= 75% WT.
- `functionally_preserved`: median > 75% and <= 140% WT.
- `functionally_preserved` with subclass `supertrans`: median > 140% WT.
- `indeterminate`: fewer than eight values or no captured standardized panel.

Median calculation is over all eight displayed values, including zeros. Do not substitute Saos-2 values into the yeast panel. Do not average across different cell systems.

## B. Overall functional phenotype

The overall label is distinct from the primary assay bin:

- `functionally_abnormal`: strong consistent loss of protein activity across the standardized panel, with supportive functional evidence.
- `functionally_preserved`: preserved standardized activity and no captured evidence that invalidates the protein-level conclusion.
- `mixed_or_context_dependent`: partial residual activity, promoter-specific variation, or meaningful differences among functional assays/systems.
- `indeterminate`: a major evidence gap or confound prevents an overall conclusion (e.g., protein-only activity looks preserved but a possible splice disruption is flagged).

This is an evidence-adjudication label, not clinical pathogenicity.

## C. Independent recomputation

The median and primary assay label are recomputed from the displayed raw values in this curated slice, without using the NCI `TransactivationClass` field as the calculation input. The NCI class is retained only for comparison and discrepancy review.

## D. Evidence hierarchy

1. Exact raw assay values and method/context from the NCI TP53 variant record.
2. Original assay publication (PMID 12826609 for the Kato systematic yeast panel).
3. Other functional studies summarized in the NCI record, kept assay-specific.
4. ClinVar or other clinical database assertions are context only; they do not replace functional measurements and are not used to label clinical pathogenicity here.
5. In-silico scores, hotspot status, or tumor recurrence are not functional measurements.

## E. Missingness and confounding

- Missing assay values remain missing.
- A panel label cannot be calculated from a partial set of promoter values.
- Potential splicing effects must be surfaced separately from protein-only assays.
- Discordant assays are not averaged into a single numeric score.
- A reported DNE label does not by itself establish gain-of-function.
