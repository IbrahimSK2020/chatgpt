# Changelog

## 1.1.0 — 2026-10-23

Material changes to the Oracle, the verifier and the scoring semantics; version
incremented accordingly. `benchmark_version` is now `1.1.0` in the task input,
the answer key, both schemas and the submission template.

### Scientific verification
- Verified the Kato threshold rule verbatim against the official NCI TP53
  Database User Manual; the repository's thresholds match exactly.
- Confirmed the bulk filename `FunctionIshiokaDownload_r21.csv` and its column
  layout from the official manual.
- Recomputed all 11 medians from the raw values using exact rational arithmetic;
  all agree with the stored key with no floating-point drift.
- Cross-checked the recomputed bins against NCI's own `TransactivationClass`:
  agreement on 10 of 10 cases where a class exists.
- Recorded a new pooling hazard: the bulk file carries Saos-2 human-cell columns
  beside the yeast columns (D-06).

### Provenance (gate remains open)
- Added `validation/bulk_reconciliation.csv` (88 rows, all
  `not_verified_source_unavailable`, observed values empty).
- Added `validation/source_access_blocker.md` documenting the exact retrieval
  failures. No checksum is recorded because no official file bytes were obtained.
- Added a test that fails if the gate is marked complete without real observed
  values.

### Oracle
- Now fails loudly on: unsupported labels, clinical-pathogenicity claims in the
  key, key annotations that disagree with the task input, evidence IDs that are
  unknown or not declared in the case's own provenance, duplicate evidence IDs,
  missing key fields, boolean/null/NaN/infinite measurements, a non-yeast cell
  system, and tampering with `expected_promoters`.
- The `>140` supertrans branch is written out explicitly; `panel_subclass()`
  preserves the subclass the four-label schema cannot express.
- Output is sorted by `case_id`, so ordering no longer depends on input order.

### Verifier
- Independence is now enforced by a test asserting `oracle` is absent from
  `sys.modules` after import, not merely asserted in a comment.
- The shipped JSON Schema is now actually executed, via a new dependency-free
  `verifier/schema_check.py`.
- **Scoring change:** evidence provenance, source-annotation fidelity and
  clinical scope are gating. Violating any of them zeroes the case.
- Submitted assay labels are now checked for consistency with the independently
  recomputed median, not only against the key.
- Rationale now requires ≥8 non-identifier tokens, defeating bare
  identifier-stuffing.
- Reports carry an explicit `limitations` array and schema-validation counters.

### Tests
- 28 → 124 tests. Added boundary coverage at 20/75/140 and just above and below
  each; float-drift cases; row- and key-order invariance; boolean/null/non-finite
  rejection; above-100% values as legal data; cell-system separation; the splice
  confound; the clinical-pathogenicity invariant; Oracle determinism across
  subprocesses; a socket guard proving the Oracle makes no network calls; CSV
  cross-file consistency; schema contract tests; and packaging/leakage tests.
- Adversarial tests now assert *which* error fires, not merely that the
  submission failed.

### Packaging
- `build_solver_bundle.py` no longer rewrites `README_solver.md` as a side
  effect, and produces byte-identical archives via fixed ZIP timestamps and
  sorted members. It now also builds the developer package.
- Added `scripts/audit_solver_bundle.py`: ZIP integrity, path-traversal checks,
  forbidden-path checks, key-token scanning, and a structural per-object leak
  check. Validated by a planted-leak negative control.
- Removed `__pycache__`/`.pyc` artifacts from the tree and excluded them from
  builds.

### Documentation
- Added `validation/discrepancy_log.md` (D-01…D-10),
  `docs/blinded_review_worksheet.csv` (empty, blinding verified),
  `docs/cohort2_proposal.md` with the G1–G10 release gates, and
  `FINAL_REPORT.md`.
- Rewrote `README.md` and `validation/known_limitations.md`.
- Removed `CLAUDE_ENHANCEMENT_PROMPT.md` from the shipped package.

### Known open blockers
D-01, D-02, D-04, D-05, D-09, D-10. Gates G1, G2, G3, G8, G9, G10 fail.

## 1.0.0 — 2026-10-23

- Added deterministic Oracle and independent verifier.
- Added task-facing input packet with gold labels removed.
- Added provisional reference answer key and reference submission example.
- Added JSON schemas, test suite, human review rubric, and enhancement brief.
- Preserved source-page reconciliation; marked bulk-file audit and second-review
  gates as open.
- Added solver-only package builder.
