# Clinical TP53 Variant Functional Adjudication — v1.1.0 developer build

**Technical status:** the Oracle, the independent verifier, the schemas, the
test suite and the packaging workflow operate reproducibly. 124 tests pass.

**Scientific status:** NOT release-ready. Official bulk-source reconciliation is
blocked, and no qualified independent reviewer has adjudicated the overall
labels. This is a provisional research pilot, not an expert-panel gold standard.
See `validation/known_limitations.md` and `docs/cohort2_proposal.md` for the
measurable gates that are currently failing (G1, G2, G3, G8, G9, G10).

## What this project asks of a solver

Adjudicate 11 TP53 functional-evidence cases from a fixed, versioned evidence
packet, producing three strictly separate outputs:

1. **Standardized assay classification** — recomputed from the median of eight
   Kato et al. yeast transactivation measurements.
2. **Overall functional phenotype** — a case-level evidence judgement that may
   account for promoter heterogeneity, assay context, and splice confounding.
   It is *not* derived from output 1.
3. **Clinical pathogenicity** — out of scope. Always `not_assessed`, enforced by
   the Oracle, the verifier, the schema and the tests.

## Scientific thresholds

Verified verbatim against the NCI TP53 Database User Manual
(<https://tp53.cancer.gov/help>, `TransactivationClass`) on 2026-10-23:

- median ≤ 20% WT → `functionally_abnormal` (upstream: non-functional)
- 20% < median ≤ 75% → `mixed_or_context_dependent` (partially functional)
- 75% < median ≤ 140% → `functionally_preserved` (functional)
- median > 140% → upstream `supertrans`; collapsed here to
  `functionally_preserved`, with the subclass retained out-of-band by
  `oracle.panel_subclass()`. Rationale and information loss: discrepancy D-03.

Do not pool assays from different cell systems into this median. The upstream
bulk file contains Saos-2 human-cell columns beside the yeast columns; see D-06.

## Setup

Python 3.9+ standard library only. No third-party dependencies, no network
access at any point. Verified on Python 3.12.3.

```bash
cd clinical-tp53-variant-adjudication-v1.1.0
python3 --version
```

## Commands

```bash
# 1. Regenerate the reference submission (deterministic, offline)
python3 oracle/oracle.py --output oracle/reference_submission.json

# 2. Verify a submission; exit 0 = PASS, 1 = FAIL, report is machine-readable
python3 verifier/verify.py oracle/reference_submission.json \
        --report validation/reference_verifier_report.json

# 3. Validate documents against the shipped schemas
python3 verifier/schema_check.py data/task_input.json schemas/task_input.schema.json
python3 verifier/schema_check.py oracle/reference_submission.json schemas/submission.schema.json

# 4. Full test suite
python3 -m unittest discover -s tests -v

# 5. Build both packages (deterministic; prints sizes and SHA-256)
python3 scripts/build_solver_bundle.py --outdir ../dist

# 6. Audit the solver archive for answer leakage and ZIP integrity
python3 scripts/audit_solver_bundle.py ../dist/clinical-tp53-variant-adjudication-v1.1.0-solver-only.zip
```

Step 6 is a release gate: it exits non-zero on any finding.

## Layout

| Path | Purpose |
|---|---|
| `data/task_input.json` | Task-facing packet: assay values, source annotations, evidence notes, source registry. No gold labels. |
| `data/promoter_activities.csv` | The 88 measurements in long form; cross-checked against the JSON by tests. |
| `data/source_manifest.csv` | Upstream provenance and access dates. |
| `data/source_reconciliation.csv` | Page-level reconciliation notes (not bulk-file). |
| `oracle/oracle.py` | Deterministic reference generator. Fails loudly; never substitutes values. |
| `oracle/reference_answers.json` | **Answer key. Developer bundle only.** |
| `verifier/verify.py` | Independent scorer. Does not import the Oracle. |
| `verifier/schema_check.py` | Dependency-free JSON Schema subset validator. |
| `tests/` | 124 tests: integrity, thresholds, adversarial submissions, packaging. |
| `scripts/build_solver_bundle.py` | Deterministic packaging, no working-tree side effects. |
| `scripts/audit_solver_bundle.py` | Leakage and ZIP-integrity audit. |
| `docs/blinded_review_worksheet.csv` | **Empty.** For a qualified reviewer; labels withheld. |
| `docs/human_review_rubric.md` | Rubric and blinded review procedure. |
| `docs/cohort2_proposal.md` | Cohort redesign and the G1–G10 release gates. |
| `validation/test_results.txt` | Captured output of a real run. |
| `validation/known_limitations.md` | Structural limitations. Read before using this. |
| `validation/discrepancy_log.md` | D-01…D-10, with status and proposed resolutions. |
| `validation/bulk_reconciliation.csv` | 88 rows, all `not_verified_source_unavailable`. |
| `validation/source_access_blocker.md` | Exactly why the provenance gate is blocked. |

**Never expose `oracle/`, `curation/`, or `validation/` to a scored solver.** Use
the solver archive from step 5 and audit it with step 6.

## Scoring

100 points per case: panel label 30, overall label 30, median 15, evidence 10,
source annotations 5, clinical boundary 5, rationale shape 5.

Evidence provenance, source-annotation fidelity and clinical scope are **gating**.
A case that invents an evidence identifier, misreports an NCI annotation, or
asserts clinical pathogenicity scores **zero for that case**, even if every label
matches. Guessing the right bin while fabricating provenance is not a correct
answer.

A `PASS` means agreement with a provisional key on objective checks. It is not
evidence of biological truth or expert consensus.

## Before any external release

Clear D-04 (bulk reconciliation), complete the blinded review, resolve D-01, D-02
and D-09, expand the cohort per `docs/cohort2_proposal.md`, and re-check upstream
redistribution terms. Do not claim scientific readiness because the tests pass.
