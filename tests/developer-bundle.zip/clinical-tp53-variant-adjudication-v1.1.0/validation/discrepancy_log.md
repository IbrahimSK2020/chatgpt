# Discrepancy log

Every entry records an observed conflict, the evidence for it, a proposed
resolution, and its current status. **No curated measurement was changed to
resolve any of these.** Entries that would require changing a scientific label
are left open for a qualified reviewer.

Status values: `OPEN` (unresolved), `DOCUMENTED` (accepted and recorded, no
change warranted), `FIXED` (code or non-scientific metadata corrected).

---

## D-01 — `validated_polymorphism` vocabulary does not match the upstream field

**Status:** OPEN — needs reviewer decision.

The NCI User Manual defines the `Polymorphism` column with three values:
`Validated` (MAF > 0.001 in ESP6500, 1000G or gnomAD), `No`, and `NA`. This
project's `validated_polymorphism` field uses `{Yes, No}` and maps upstream
`Validated` → `Yes`.

The two-value enum cannot represent upstream `NA`. Both cases currently marked
`Yes` (TP53-009 p.P72R, TP53-011 p.V31I) are well-established common
polymorphisms, so the present data is not wrong, but the enum will silently
misrepresent any future variant whose upstream value is `NA`.

*Proposed resolution:* widen the enum to `{Validated, No, NA}` and re-derive from
the bulk file during the D-04 reconciliation. Deferred because it is a
submission-contract change that should be made once, together with the bulk
reconciliation, rather than twice.

---

## D-02 — `nci_dne_lof_class` enum contains values that are not upstream values

**Status:** OPEN — needs reviewer decision.

The manual defines `DNE_LOFclass` over exactly four values derived from
Giacomelli et al. (2018) Z-scores: `DNE_LOF`, `notDNE_notLOF`, `notDNE_LOF`,
`unclass`. This project's enum adds `NA` and `Indeterminate`.

TP53-009 (p.P72R) currently carries `nci_dne_lof_class = "NA"`, which is not a
value the upstream classifier emits. It most likely encodes *"no Giacomelli
Z-score record exists for this variant"*, which upstream would express by the
absence of a row or by `unclass`.

*Proposed resolution:* determine from `MutationView_r21.csv` whether p.P72R has a
`DNE_LOFclass` value at all. If it does not, decide explicitly whether "absent"
should be represented as `unclass` (upstream vocabulary) or retained as a
project-local `NA` with that meaning documented. Blocked on D-04.

---

## D-03 — `supertrans` is collapsed into `functionally_preserved`

**Status:** DOCUMENTED — retained deliberately.

The source vocabulary has four bins; the submission contract has four labels but
a different fourth one (`indeterminate`), so `supertrans` (median >140%) has no
dedicated label and is mapped to `functionally_preserved`.

*Justification for retaining the mapping:* supertrans denotes transactivation at
or above wild-type level. The panel shows no impairment, so mapping it to
`functionally_preserved` asserts nothing the measurement contradicts; it only
discards the "above wild-type" nuance. Introducing a fifth label would change the
solver contract for a category that **no case in the current cohort occupies**.

*Mitigation implemented:* `oracle.panel_subclass()` computes and preserves the
subclass separately, the `>140` branch is now written out explicitly in
`panel_label()` rather than falling through, and both are covered by unit tests.
A cohort containing a real supertrans variant (D-10) should force this decision
to be revisited.

---

## D-04 — Bulk-file reconciliation not performed

**Status:** OPEN — hard release blocker.

All 88 values trace to NCI variant-detail *pages*, not to the official bulk
download. No file checksum exists. Full detail, including the exact retrieval
failures, is in `validation/source_access_blocker.md`.

---

## D-05 — p.R156C notation correction is inherited, not re-verified

**Status:** OPEN.

`curation/decision_log.md` records that v0.1.1 corrected p.R156C from
`c.465_466delinsTT` to `c.466C>T` and the source URL from `mut_id=20288` to
`mut_id=1811`. The corrected values are internally consistent across
`task_input.json`, `promoter_activities.csv` and `source_reconciliation.csv`, and
a regression test now pins them.

However, the correction itself was **not** re-verified against the official
source in this session (the variant-detail page is unreachable, D-04). The
project therefore asserts a correction it cannot currently re-demonstrate.
`c.466C>T` → p.Arg156Cys is consistent with the NM_000546.5 reading frame
(codon 156 CGC→TGC), which is a coherence check, not source verification.

---

## D-06 — Bulk file mixes yeast and Saos-2 columns (pooling hazard)

**Status:** DOCUMENTED — new finding, mitigation specified.

`FunctionIshiokaDownload_r21.csv` contains both the yeast promoter columns
(`WAF1nWT`, `MDM2nWT`, …) and human Saos-2 columns (`WAF1nWT_Saos2`, …) plus
`SubG1nWT_Saos2`. A bulk reconciliation that selects promoter columns by name
prefix would silently pool two cell systems into one median, violating
`curation/criteria.md` §A.

*Mitigation implemented:* the Oracle now refuses any case whose
`primary_assay.cell_system` is not `yeast`
(`test_oracle.py::test_non_yeast_cell_system_is_refused`), and
`validation/bulk_reconciliation.csv` names the required source column per row so
the column selection is explicit rather than inferred.

---

## D-07 — Evidence notes are verbatim duplicates in 10 of 11 cases

**Status:** FIXED (documented) — data unchanged.

In TP53-001 through TP53-010, `additional_evidence.splicing_or_scope_note` and
`additional_evidence.secondary_evidence_summary` hold byte-identical strings.
Only TP53-011 carries genuinely distinct content in the two fields.

This is a curation artifact, not a measurement error, but it is misleading: a
solver reading two differently-named fields may reasonably treat them as two
independent pieces of evidence and double-weight a single observation. For
TP53-010 the duplicated string is the splice confound, which is the single most
decision-relevant note in the cohort.

*Resolution:* the field values are left untouched (changing them would alter the
task-facing evidence packet mid-audit). The duplication is documented here and in
`validation/known_limitations.md`, and a reviewer question is included in the
blinded worksheet. Collapsing the two fields into one is proposed for v1.2.0.

---

## D-08 — Two registry sources are never required by any case

**Status:** DOCUMENTED — not an error.

`SRC-001` (About page) and `SRC-003` (downloads page) appear in the source
registry but in no case's `required_evidence_ids`. They document release identity
and provenance rather than per-case evidence. They are retained deliberately;
the Oracle now rejects any key that cites a source not declared in that case's
own provenance, so their presence cannot be used to pad an evidence list.

---

## D-09 — Overall label for TP53-011 (p.V31I) rests on unidentified evidence

**Status:** OPEN — scientific disagreement, flagged for independent review.

The overall phenotype for p.V31I is `mixed_or_context_dependent`, justified by a
summary of "partial WAF1/MDM2 activity and retained BAX activity in another
assay". That conflicting evidence has **no identified source row, cell system,
construct, or PMID** in the evidence packet — only prose in
`secondary_evidence_summary`.

`curation/criteria.md` §D ranks evidence by identifiable assay records and
requires assay contexts to be kept separate. By the project's own hierarchy, an
unattributed narrative summary is weak grounds for overriding a complete,
source-identified eight-promoter panel with median 108.75% WT and an NCI class of
`functional`, for a validated polymorphism.

*Defensible alternatives a reviewer should weigh:*
- `functionally_preserved` — the only identifiable assay evidence shows preserved function.
- `indeterminate` — conflicting contexts exist but the conflicting evidence is too poorly specified to adjudicate.
- `mixed_or_context_dependent` — the current label, if the reviewer judges the summarised evidence sufficient.

**The label has not been changed.** Changing a scientific label to match an
auditor's reading, without source access or qualified review, is exactly the
failure mode this project is built to avoid. See
`validation/known_limitations.md` §2.

---

## D-10 — Cohort is small, hotspot-heavy, and bimodal

**Status:** OPEN — benchmark-design blocker, not a data error.

Six of eleven cases (TP53-001…006) are canonical hotspots with medians ≤9.15%
and NCI class `non-functional`; all six are labelled identically on both label
axes. Measured bins cluster at the extremes: six cases ≤9.15%, two in the 62–69%
band, three ≥78.7%. No case has a median near the 20% boundary, none exceeds
140% (so the supertrans path is untested by real data, D-03), and only one case
(TP53-010) is genuinely hard.

A model could score 6/11 on the overall-label axis by emitting
`functionally_abnormal` for anything recognisable as a hotspot — the exact
inference `instruction.md` forbids.

*Proposed resolution:* `docs/cohort2_proposal.md`.
