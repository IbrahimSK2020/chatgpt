# Known limitations — v1.1.0

These limitations are structural. They are not resolved by the test suite
passing, and several of them cannot be resolved inside this environment at all.

## 1. Bulk-source reconciliation is NOT complete

All 88 promoter values and 11 variant identities trace to NCI variant-detail
pages recorded by a prior curator. They have **not** been compared against a
checksum-identified bulk R21 download, and no official file checksum exists in
this repository. `validation/bulk_reconciliation.csv` carries all 88 rows with
`match_status = not_verified_source_unavailable` and an empty observed value.
The exact retrieval failures are recorded in
`validation/source_access_blocker.md`. This is a hard release blocker (D-04).

What *was* verified against the official NCI User Manual in this session: the
threshold rule, and the bulk filename and column layout. See the blocker file.

## 2. Overall labels are provisional and unreviewed

The overall functional phenotype labels are one curator's judgement. No
qualified independent reviewer has adjudicated them. `docs/blinded_review_worksheet.csv`
exists to enable that review but **has not been completed**; every reviewer
column in it is empty. Until it is filled in by a qualified reviewer, the answer
key is provisional and must not be described as gold-standard.

One substantive disagreement is already recorded against the current key
(TP53-011 p.V31I, D-09) and has deliberately not been actioned.

## 3. Assay bins are far stronger than overall labels — do not conflate them

The eight-promoter bins are deterministic given the transcribed values, and they
agree with NCI's own `TransactivationClass` on 10 of 10 cases where that class
exists. Confidence in the assay bin is therefore high *conditional on the
transcription being right* (limitation 1). Confidence in the overall phenotype
is materially lower and is reported separately in every submission
(`confidence.assay` vs `confidence.overall`).

## 4. The cohort is small, hotspot-heavy, and bimodal

Eleven cases, six of them canonical hotspots with concordant labels on both
axes. No median lies near the 20% boundary; none exceeds 140%, so the supertrans
code path is exercised only by unit tests. A hotspot-recognition heuristic scores
well without doing the task. See D-10 and `docs/cohort2_proposal.md`.

## 5. Automated verification cannot establish scientific validity

The verifier checks structure, arithmetic, provenance and scope. It does not and
cannot establish that free-text reasoning is biologically correct, nor that the
provisional key is right. A `PASS` means agreement with a provisional key, not
truth. The report states this in its own `limitations` field.

## 6. Rationale checking remains partially gameable

The rationale check requires minimum length, citation of each required evidence
identifier, and at least eight non-identifier tokens. This raises the cost of
identifier-stuffing but does not establish that the prose is relevant or
correct. Human review remains mandatory.

## 7. Supertrans information loss

Median >140% is mapped to `functionally_preserved` because the submission
contract has no supertrans label. `oracle.panel_subclass()` preserves the
distinction out-of-band. See D-03.

## 8. Source-annotation vocabularies diverge from upstream

`validated_polymorphism` uses `{Yes, No}` where upstream uses
`{Validated, No, NA}` (D-01), and `nci_dne_lof_class` admits `NA` and
`Indeterminate`, which the upstream Giacomelli-derived classifier does not emit
(D-02). Neither affects the current eleven cases' correctness, and both will
misrepresent future variants.

## 9. Duplicated evidence fields invite double-counting

In 10 of 11 cases `splicing_or_scope_note` and `secondary_evidence_summary` are
byte-identical, so a solver may treat one observation as two (D-07).

## 10. Snapshot freshness and redistribution terms

R21 (January 2025) is the identified upstream release, but the web application
is updated independently of the data release. Access dates and URLs are
retained. Upstream redistribution terms have not been re-checked in this
session; see `LICENSE_AND_ATTRIBUTION.md` before any public release.

## 11. No clinical classification

Clinical pathogenicity is out of scope and is pinned to `not_assessed` by the
Oracle, the verifier, the schema, and the test suite. This project is not
clinical decision-support software and must not be used to classify a patient's
variant.
