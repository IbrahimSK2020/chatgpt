# Official bulk-source access blocker — recorded 2026-10-23

This file records, precisely, why the bulk-file reconciliation gate is **not**
complete. It exists so that no later reader mistakes an unattempted check for a
passed one.

## Status

| Gate | Status |
|---|---|
| Variant-detail page reconciliation (inherited from v0.1.1) | claimed by prior curator; **not re-executed** in this session |
| Official threshold rule verified against the NCI User Manual | **COMPLETE** (see below) |
| Official bulk file retrieved, checksummed, row-by-row compared | **BLOCKED — NOT COMPLETE** |

## What was verified against an official source

The NCI TP53 Database User Manual (<https://tp53.cancer.gov/help>) was retrieved
and read in this session. Two repository claims were confirmed verbatim against
it:

1. **The threshold rule.** The manual's `TransactivationClass` column definition
   states that for each mutant the median of the 8 promoter-specific activities
   (percent of wild-type) is calculated, and missense variants are classified as
   non-functional if the median is ≤20, partially functional if >20 and ≤75,
   functional if >75 and ≤140, and supertrans if >140. This matches
   `data/task_input.json → thresholds` exactly.

2. **The bulk filename and its column layout.** The systematic yeast panel lives
   in `FunctionIshiokaDownload_r21.csv`, whose promoter columns are named
   `WAF1nWT`, `MDM2nWT`, `BAXnWT`, … The repository's assumed filename was
   therefore correct.

   The same file **also** contains `WAF1nWT_Saos2`, `MDM2nWT_Saos2`, … columns
   holding human Saos-2 cell-line measurements, plus `SubG1nWT_Saos2`. This is a
   concrete, previously undocumented pooling hazard: a careless bulk
   reconciliation that globs promoter-named columns would silently mix two cell
   systems into one median. See discrepancy D-06.

## What is blocked, and exactly why

The byte-level artifact — the actual `FunctionIshiokaDownload_r21.csv` — could
not be obtained. Two independent retrieval paths were attempted and both failed:

**1. Container network egress.** The execution container's egress allowlist does
not include the NCI host. DNS resolution fails before any TLS handshake:

```
$ curl -sS --max-time 20 https://tp53.cancer.gov/get_tp53data
curl: (6) Could not resolve host: tp53.cancer.gov
$ getent hosts tp53.cancer.gov
(no output; exit 2)
```

The same failure applies to `https://www.ncbi.nlm.nih.gov/` (ClinVar, SRC-016).

**2. Assistant-side document retrieval.** This path can return *rendered page
text*, which is how the User Manual content above was confirmed. It cannot
return a raw file byte stream. The download controls on
`https://tp53.cancer.gov/get_tp53data` are JavaScript-rendered and resolve to
Google Cloud Storage objects at runtime; the static HTML exposes no direct file
URL, so no CSV URL could be reached even indirectly.

## Why no checksum is recorded

A SHA-256 is only meaningful if computed over the bytes the official server
served. Hashing assistant-extracted page text and labelling it a file checksum
would be a fabricated provenance record. **No checksum is therefore recorded.**
`validation/bulk_reconciliation.csv` carries all 88 rows with
`observed_value_pct_wt` empty and `match_status =
not_verified_source_unavailable`, and `tests/test_data_integrity.py` asserts that
this remains the case — the test fails if anyone marks the gate complete without
supplying real observed values.

## Required to clear this gate

1. Download `FunctionIshiokaDownload_r21.csv` and `MutationView_r21.csv` from
   <https://tp53.cancer.gov/get_tp53data> on a host with egress to NCI.
2. Record filename, retrieval timestamp, byte size, SHA-256, and the terms of
   use stated on the download page.
3. Populate `observed_value_pct_wt` and `source_row_key` for all 88 rows, taking
   values **only** from the non-`_Saos2` promoter columns (D-06).
4. Record every mismatch rather than overwriting curated values, and resolve
   each one in `validation/discrepancy_log.md`.
5. Re-verify the eleven `ProtDescription` / `c_description` identities against
   `MutationView_r21.csv`, including the corrected p.R156C notation (D-05).
