# Sources and provenance

All access dates in this pilot: **2026-10-22**.

1. NCI TP53 Database, About and R21 release information: https://tp53.cancer.gov/about
2. NCI TP53 Database User Manual, including Kato transactivation thresholds and caution on assay comparability: https://tp53.cancer.gov/help
3. NCI TP53 Database downloads page: https://tp53.cancer.gov/get_tp53data
4. Kato et al. 2003, PMID 12826609: https://pubmed.ncbi.nlm.nih.gov/12826609/
5. Selected variant-detail records are listed individually in `data/source_manifest.csv`. These pages are the source for the displayed eight-promoter values and NCI annotations.
6. ClinVar VCV000127827 (p.Val31Ile) is used only for secondary functional evidence context: https://www.ncbi.nlm.nih.gov/clinvar/variation/127827/

## Verification status by source (added v1.1.0, 2026-10-23)

| Source | Verified in this session? |
|---|---|
| SRC-002 User Manual — Kato threshold rule | **YES.** Retrieved and read; `TransactivationClass` definition matches `thresholds` exactly. |
| SRC-002 User Manual — bulk filename and columns | **YES.** `FunctionIshiokaDownload_r21.csv`; yeast columns `WAF1nWT`… alongside Saos-2 columns `WAF1nWT_Saos2`… (see D-06). |
| SRC-001 About / R21 identity | Partially. R21 (January 2025) corroborated. |
| SRC-003 Downloads page | Page listing seen; **no file bytes retrieved**. |
| SRC-005…SRC-015 variant-detail pages | **NO.** Unreachable in this environment; page-level reconciliation is inherited from the prior curator and was not re-executed. |
| SRC-016 ClinVar VCV000127827 | **NO.** Host unreachable. |
| Bulk R21 data files | **NO.** Not retrieved, not checksummed. Gate OPEN. |

See `validation/source_access_blocker.md` for the exact retrieval failures.

## Version semantics

- **Upstream release:** NCI TP53 Database R21, documented as January 2025.
- **Upstream web app:** version 1.1.4, last updated 2026-05-29 on the accessed NCI pages.
- **Curated slice version:** 0.1.0, frozen 2026-10-22. **Benchmark package version:** 1.1.0 (2026-10-23).
- **No full upstream CSV is bundled.** This pilot contains a small set of selected measurements transcribed from the variant detail pages. The source manifest and per-row URLs provide provenance. A case-by-case comparison against the official NCI variant-detail pages is recorded in `curation/source_reconciliation_report.md`. The bulk R21 CSV has not yet been captured/checksummed, so bulk-file reconciliation remains outstanding before expert gold-standard release.
