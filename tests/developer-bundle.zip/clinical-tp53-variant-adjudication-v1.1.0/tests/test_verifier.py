"""Verifier tests: adversarial submissions, independence, and integrity gating.

Each adversarial test asserts not only that the submission FAILs, but which
error field fires. A test that only checks `status == FAIL` would still pass if
the verifier failed the submission for an unrelated reason.
"""
import copy
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "verifier"))
from verify import expected_panel_label, independent_median, load, verify  # noqa: E402

INPUT = load(ROOT / "data/task_input.json")
KEY = load(ROOT / "oracle/reference_answers.json")
SCHEMA = load(ROOT / "schemas/submission.schema.json")
REFERENCE = load(ROOT / "oracle/reference_submission.json")


def run(submission):
    return verify(submission, INPUT, KEY, SCHEMA)


def fields(report):
    return {error["field"] for error in report["errors"]}


class IndependenceTests(unittest.TestCase):
    def test_verifier_does_not_import_oracle(self):
        """Enforces the independence contract in a clean interpreter."""
        code = (
            "import sys; sys.path.insert(0, r'%s');"
            "import verify;"
            "assert 'oracle' not in sys.modules, sorted(sys.modules);"
            "print('INDEPENDENT')" % (ROOT / "verifier")
        )
        result = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True)
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("INDEPENDENT", result.stdout)

    def test_verifier_source_contains_no_oracle_import(self):
        source = (ROOT / "verifier/verify.py").read_text(encoding="utf-8")
        self.assertNotIn("from oracle", source)
        self.assertNotIn("import oracle", source)

    def test_verifier_recomputes_medians_itself(self):
        for case in INPUT["cases"]:
            median = independent_median(case["primary_assay"]["measurements_pct_wt"])
            key = next(k for k in KEY["cases"] if k["case_id"] == case["case_id"])
            self.assertAlmostEqual(median, key["median_pct_wt"], places=9, msg=case["case_id"])
            self.assertEqual(expected_panel_label(median), key["protein_assay_label"])


class ReferenceTests(unittest.TestCase):
    def test_reference_passes(self):
        report = run(REFERENCE)
        self.assertEqual(report["status"], "PASS", report["errors"])
        self.assertEqual(report["score"], 100.0)
        self.assertTrue(report["schema_validated"])
        self.assertEqual(report["schema_error_count"], 0)

    def test_report_declares_limitations(self):
        report = run(REFERENCE)
        self.assertTrue(report["limitations"])
        joined = " ".join(report["limitations"]).lower()
        self.assertIn("human review", joined)
        self.assertIn("not complete", joined)

    def test_report_is_json_serialisable_with_per_case_breakdown(self):
        report = run(REFERENCE)
        json.dumps(report)
        self.assertEqual(set(report["score_breakdown_by_case"]),
                         {case["case_id"] for case in INPUT["cases"]})


class CaseCoverageTests(unittest.TestCase):
    def test_missing_case_fails(self):
        bad = copy.deepcopy(REFERENCE)
        bad["cases"].pop()
        report = run(bad)
        self.assertEqual(report["status"], "FAIL")
        self.assertIn("case_id", fields(report))
        self.assertIn("case_count", fields(report))

    def test_duplicate_case_fails(self):
        bad = copy.deepcopy(REFERENCE)
        bad["cases"].append(copy.deepcopy(bad["cases"][0]))
        report = run(bad)
        self.assertEqual(report["status"], "FAIL")
        self.assertIn("case_id", fields(report))

    def test_extra_unknown_case_fails(self):
        bad = copy.deepcopy(REFERENCE)
        ghost = copy.deepcopy(bad["cases"][0])
        ghost["case_id"] = "TP53-999"
        bad["cases"].append(ghost)
        report = run(bad)
        self.assertEqual(report["status"], "FAIL")
        self.assertIn("case_id", fields(report))

    def test_empty_cases_fails(self):
        bad = copy.deepcopy(REFERENCE)
        bad["cases"] = []
        self.assertEqual(run(bad)["status"], "FAIL")

    def test_cases_not_a_list_fails(self):
        bad = copy.deepcopy(REFERENCE)
        bad["cases"] = {"TP53-001": {}}
        self.assertEqual(run(bad)["status"], "FAIL")

    def test_non_object_submission_fails(self):
        for value in ("a string", 42, None, ["a", "list"]):
            self.assertEqual(run(value)["status"], "FAIL")


class NumericTests(unittest.TestCase):
    def test_wrong_median_fails(self):
        bad = copy.deepcopy(REFERENCE)
        bad["cases"][0]["median_pct_wt"] += 2
        report = run(bad)
        self.assertEqual(report["status"], "FAIL")
        self.assertIn("median_pct_wt", fields(report))

    def test_median_within_tolerance_passes(self):
        ok = copy.deepcopy(REFERENCE)
        ok["cases"][0]["median_pct_wt"] += 1e-7
        self.assertEqual(run(ok)["status"], "PASS")

    def test_median_outside_tolerance_fails(self):
        bad = copy.deepcopy(REFERENCE)
        bad["cases"][0]["median_pct_wt"] += 1e-2
        self.assertIn("median_pct_wt", fields(run(bad)))

    def test_string_median_fails(self):
        bad = copy.deepcopy(REFERENCE)
        bad["cases"][0]["median_pct_wt"] = "9.15"
        self.assertIn("median_pct_wt", fields(run(bad)))

    def test_boolean_median_fails(self):
        bad = copy.deepcopy(REFERENCE)
        bad["cases"][0]["median_pct_wt"] = True
        self.assertIn("median_pct_wt", fields(run(bad)))


class LabelTests(unittest.TestCase):
    def test_wrong_panel_label_fails(self):
        bad = copy.deepcopy(REFERENCE)
        bad["cases"][0]["protein_assay_label"] = "functionally_preserved"
        self.assertIn("protein_assay_label", fields(run(bad)))

    def test_wrong_overall_label_fails(self):
        bad = copy.deepcopy(REFERENCE)
        bad["cases"][0]["overall_functional_phenotype"] = "indeterminate"
        self.assertIn("overall_functional_phenotype", fields(run(bad)))

    def test_invalid_label_value_fails(self):
        bad = copy.deepcopy(REFERENCE)
        bad["cases"][0]["protein_assay_label"] = "pathogenic"
        self.assertIn("protein_assay_label", fields(run(bad)))

    def test_swapped_labels_across_two_cases_fails(self):
        bad = copy.deepcopy(REFERENCE)
        bad["cases"][0]["protein_assay_label"], bad["cases"][-1]["protein_assay_label"] = (
            bad["cases"][-1]["protein_assay_label"], bad["cases"][0]["protein_assay_label"])
        self.assertEqual(run(bad)["status"], "FAIL")

    def test_collapsing_overall_into_panel_label_is_caught(self):
        """The splice-confounded case must not inherit the protein-only bin."""
        bad = copy.deepcopy(REFERENCE)
        for case in bad["cases"]:
            case["overall_functional_phenotype"] = case["protein_assay_label"]
        report = run(bad)
        self.assertEqual(report["status"], "FAIL")
        self.assertIn("overall_functional_phenotype", fields(report))


class ProvenanceTests(unittest.TestCase):
    def test_missing_evidence_fails(self):
        bad = copy.deepcopy(REFERENCE)
        bad["cases"][0]["evidence_ids"] = []
        self.assertIn("evidence_ids", fields(run(bad)))

    def test_invented_evidence_id_fails_and_is_named(self):
        bad = copy.deepcopy(REFERENCE)
        bad["cases"][0]["evidence_ids"].append("SRC-FAKE")
        report = run(bad)
        self.assertEqual(report["status"], "FAIL")
        message = " ".join(e["error"] for e in report["errors"] if e["field"] == "evidence_ids")
        self.assertIn("SRC-FAKE", message)

    def test_duplicate_evidence_ids_fail(self):
        bad = copy.deepcopy(REFERENCE)
        bad["cases"][0]["evidence_ids"].append(bad["cases"][0]["evidence_ids"][0])
        self.assertIn("evidence_ids", fields(run(bad)))

    def test_dne_annotation_mismatch_fails(self):
        bad = copy.deepcopy(REFERENCE)
        bad["cases"][0]["nci_dne_class"] = "No"
        self.assertIn("source_annotations", fields(run(bad)))

    def test_dne_lof_annotation_mismatch_fails(self):
        bad = copy.deepcopy(REFERENCE)
        bad["cases"][0]["nci_dne_lof_class"] = "notDNE_notLOF"
        self.assertEqual(run(bad)["status"], "FAIL")

    def test_invalid_polymorphism_enum_fails(self):
        bad = copy.deepcopy(REFERENCE)
        bad["cases"][0]["validated_polymorphism"] = "Maybe"
        self.assertIn("validated_polymorphism", fields(run(bad)))


class IntegrityGateTests(unittest.TestCase):
    """Correct labels plus fabricated provenance must earn zero, not partial credit."""

    def test_invented_evidence_zeroes_the_case(self):
        bad = copy.deepcopy(REFERENCE)
        target = bad["cases"][0]["case_id"]
        bad["cases"][0]["evidence_ids"].append("SRC-FAKE")
        report = run(bad)
        breakdown = report["score_breakdown_by_case"][target]
        self.assertTrue(breakdown["gated_to_zero"])
        self.assertEqual(breakdown["panel_label"], 0)
        self.assertEqual(breakdown["overall_label"], 0)
        self.assertEqual(breakdown["median"], 0)
        self.assertIn("integrity_gate", fields(report))

    def test_wrong_source_annotation_zeroes_the_case(self):
        bad = copy.deepcopy(REFERENCE)
        target = bad["cases"][0]["case_id"]
        bad["cases"][0]["nci_dne_class"] = "No"
        self.assertTrue(run(bad)["score_breakdown_by_case"][target]["gated_to_zero"])

    def test_case_level_clinical_claim_zeroes_the_case(self):
        bad = copy.deepcopy(REFERENCE)
        target = bad["cases"][0]["case_id"]
        bad["cases"][0]["clinical_pathogenicity"] = "pathogenic"
        self.assertTrue(run(bad)["score_breakdown_by_case"][target]["gated_to_zero"])

    def test_top_level_clinical_claim_zeroes_every_case(self):
        bad = copy.deepcopy(REFERENCE)
        bad["clinical_pathogenicity"] = "pathogenic"
        report = run(bad)
        self.assertEqual(report["status"], "FAIL")
        self.assertEqual(report["points_earned"], 0)
        for breakdown in report["score_breakdown_by_case"].values():
            self.assertTrue(breakdown["gated_to_zero"])

    def test_otherwise_perfect_submission_with_one_fabrication_loses_whole_case(self):
        bad = copy.deepcopy(REFERENCE)
        bad["cases"][0]["evidence_ids"] = ["SRC-FAKE"]
        report = run(bad)
        self.assertLessEqual(report["score"], 100 * 10 / 11 + 0.01)


class ScopeTests(unittest.TestCase):
    def test_clinical_pathogenicity_must_be_not_assessed(self):
        for value in ("pathogenic", "benign", "likely_pathogenic", "VUS", None):
            bad = copy.deepcopy(REFERENCE)
            bad["clinical_pathogenicity"] = value
            self.assertEqual(run(bad)["status"], "FAIL")

    def test_extra_case_field_fails(self):
        bad = copy.deepcopy(REFERENCE)
        bad["cases"][0]["acmg_classification"] = "PS3"
        self.assertEqual(run(bad)["status"], "FAIL")

    def test_extra_top_level_field_fails(self):
        bad = copy.deepcopy(REFERENCE)
        bad["patient_diagnosis"] = "cancer"
        self.assertEqual(run(bad)["status"], "FAIL")

    def test_missing_required_case_field_fails(self):
        for field in ("confidence", "rationale", "evidence_ids", "median_pct_wt"):
            bad = copy.deepcopy(REFERENCE)
            del bad["cases"][0][field]
            self.assertEqual(run(bad)["status"], "FAIL", field)


class RationaleTests(unittest.TestCase):
    def test_short_rationale_fails(self):
        bad = copy.deepcopy(REFERENCE)
        bad["cases"][0]["rationale"] = "Wrong"
        self.assertIn("rationale", fields(run(bad)))

    def test_rationale_without_evidence_ids_fails(self):
        bad = copy.deepcopy(REFERENCE)
        bad["cases"][0]["rationale"] = "The median is low so the variant is abnormal in this assay."
        self.assertIn("rationale", fields(run(bad)))

    def test_bare_identifier_stuffing_fails(self):
        """Evidence IDs alone, with no reasoning, must not earn the rationale points."""
        bad = copy.deepcopy(REFERENCE)
        required = next(k for k in KEY["cases"]
                        if k["case_id"] == bad["cases"][0]["case_id"])["required_evidence_ids"]
        bad["cases"][0]["rationale"] = " ".join(required * 6)
        self.assertIn("rationale", fields(run(bad)))

    def test_non_string_rationale_fails(self):
        bad = copy.deepcopy(REFERENCE)
        bad["cases"][0]["rationale"] = ["SRC-002", "SRC-004"]
        self.assertEqual(run(bad)["status"], "FAIL")


class ConfidenceTests(unittest.TestCase):
    def test_missing_confidence_fails(self):
        bad = copy.deepcopy(REFERENCE)
        del bad["cases"][0]["confidence"]
        self.assertEqual(run(bad)["status"], "FAIL")

    def test_confidence_must_separate_assay_from_overall(self):
        bad = copy.deepcopy(REFERENCE)
        bad["cases"][0]["confidence"] = {"assay": "high_for_transcribed_panel_values"}
        self.assertIn("confidence", fields(run(bad)))

    def test_invalid_confidence_enum_fails(self):
        bad = copy.deepcopy(REFERENCE)
        bad["cases"][0]["confidence"]["overall"] = "certain"
        self.assertIn("confidence.overall", fields(run(bad)))


class VersionAndThresholdTests(unittest.TestCase):
    def test_wrong_benchmark_version_fails(self):
        bad = copy.deepcopy(REFERENCE)
        bad["benchmark_version"] = "1.0.0"
        self.assertIn("benchmark_version", fields(run(bad)))

    def test_tampered_task_input_thresholds_are_reported(self):
        tampered = copy.deepcopy(INPUT)
        tampered["thresholds"]["functionally_abnormal"]["median_lte_pct_wt"] = 30
        report = verify(REFERENCE, tampered, KEY, SCHEMA)
        self.assertIn("thresholds", fields(report))

    def test_key_median_drift_is_reported(self):
        drifted = copy.deepcopy(KEY)
        drifted["cases"][0]["median_pct_wt"] = 99.0
        report = verify(REFERENCE, INPUT, drifted, SCHEMA)
        self.assertIn("reference_key", fields(report))


class CliTests(unittest.TestCase):
    def test_malformed_json_does_not_crash_the_runner(self):
        with tempfile.TemporaryDirectory() as tmp:
            bad = Path(tmp) / "bad.json"
            bad.write_text("{ this is not json", encoding="utf-8")
            result = subprocess.run(
                [sys.executable, str(ROOT / "verifier/verify.py"), str(bad)],
                capture_output=True, text=True)
            self.assertEqual(result.returncode, 1)
            report = json.loads(result.stdout)
            self.assertEqual(report["status"], "FAIL")

    def test_cli_exit_codes(self):
        with tempfile.TemporaryDirectory() as tmp:
            good = Path(tmp) / "good.json"
            good.write_text(json.dumps(REFERENCE), encoding="utf-8")
            result = subprocess.run(
                [sys.executable, str(ROOT / "verifier/verify.py"), str(good)],
                capture_output=True, text=True)
            self.assertEqual(result.returncode, 0)
            self.assertEqual(json.loads(result.stdout)["status"], "PASS")


if __name__ == "__main__":
    unittest.main()


class CoverageGateTests(unittest.TestCase):
    """A broken case set must never be reported with a high score."""

    def test_duplicate_case_zeroes_the_score(self):
        bad = copy.deepcopy(REFERENCE)
        bad["cases"].append(copy.deepcopy(bad["cases"][0]))
        report = run(bad)
        self.assertEqual(report["status"], "FAIL")
        self.assertFalse(report["coverage_valid"])
        self.assertEqual(report["score"], 0.0)
        self.assertIn("coverage_gate", fields(report))

    def test_unknown_case_zeroes_the_score(self):
        bad = copy.deepcopy(REFERENCE)
        bad["cases"].append(dict(copy.deepcopy(bad["cases"][0]), case_id="TP53-999"))
        report = run(bad)
        self.assertEqual(report["score"], 0.0)
        self.assertFalse(report["coverage_valid"])

    def test_missing_case_zeroes_the_score(self):
        bad = copy.deepcopy(REFERENCE)
        bad["cases"].pop()
        self.assertEqual(run(bad)["score"], 0.0)

    def test_raw_points_still_reported_for_diagnosis(self):
        bad = copy.deepcopy(REFERENCE)
        bad["cases"].pop()
        report = run(bad)
        self.assertGreater(report["raw_points_score"], 0.0)
        self.assertEqual(report["score"], 0.0)

    def test_valid_coverage_leaves_score_untouched(self):
        report = run(REFERENCE)
        self.assertTrue(report["coverage_valid"])
        self.assertEqual(report["score"], report["raw_points_score"])
