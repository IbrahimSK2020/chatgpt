"""Data-integrity, cross-file-consistency, and schema-contract tests."""
import csv
import json
import statistics
import sys
import unittest
from fractions import Fraction
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "verifier"))
from schema_check import validate  # noqa: E402

INPUT = json.loads((ROOT / "data/task_input.json").read_text(encoding="utf-8"))
KEY = json.loads((ROOT / "oracle/reference_answers.json").read_text(encoding="utf-8"))
PROMOTERS = INPUT["expected_promoters"]


def read_csv(name):
    with (ROOT / name).open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


class DataIntegrityTests(unittest.TestCase):
    def test_unique_cases_and_complete_panels(self):
        ids = [case["case_id"] for case in INPUT["cases"]]
        self.assertEqual(len(ids), 11)
        self.assertEqual(len(set(ids)), 11)
        for case in INPUT["cases"]:
            measurements = case["primary_assay"]["measurements_pct_wt"]
            self.assertEqual(set(measurements), set(PROMOTERS), case["case_id"])
            self.assertEqual(len(measurements), 8, case["case_id"])
            for promoter, value in measurements.items():
                self.assertIsInstance(value, (int, float), f"{case['case_id']}/{promoter}")
                self.assertNotIsInstance(value, bool)
                self.assertGreaterEqual(value, 0)

    def test_exactly_88_promoter_measurements(self):
        total = sum(len(c["primary_assay"]["measurements_pct_wt"]) for c in INPUT["cases"])
        self.assertEqual(total, 88)

    def test_task_input_has_no_gold_label_fields(self):
        forbidden = {"protein_assay_label", "overall_functional_phenotype",
                     "reference_rationale", "adjudication_rationale", "median_pct_wt"}
        for case in INPUT["cases"]:
            self.assertFalse(forbidden.intersection(case), case["case_id"])

    def test_source_ids_resolve(self):
        known = {source["source_id"] for source in INPUT["source_registry"]}
        for case in INPUT["cases"]:
            self.assertTrue(set(case["provenance"]["source_ids"]).issubset(known), case["case_id"])

    def test_source_registry_ids_unique(self):
        ids = [source["source_id"] for source in INPUT["source_registry"]]
        self.assertEqual(len(ids), len(set(ids)))

    def test_every_panel_is_the_yeast_assay(self):
        """The standardized median must never mix cell systems."""
        for case in INPUT["cases"]:
            self.assertEqual(case["primary_assay"]["cell_system"], "yeast", case["case_id"])
            self.assertEqual(case["primary_assay"]["unit"], "percent_of_wild_type_activity")

    def test_key_medians_match_exact_rational_recomputation(self):
        """Recompute with Fractions so the check cannot inherit a float error."""
        key_by = {case["case_id"]: case for case in KEY["cases"]}
        for case in INPUT["cases"]:
            measurements = case["primary_assay"]["measurements_pct_wt"]
            exact = statistics.median([Fraction(str(measurements[p])) for p in PROMOTERS])
            self.assertEqual(
                Fraction(str(key_by[case["case_id"]]["median_pct_wt"])), exact, case["case_id"]
            )

    def test_promoter_csv_matches_task_input(self):
        rows = read_csv("data/promoter_activities.csv")
        from_csv: dict = {}
        for row in rows:
            from_csv.setdefault(row["case_id"], {})[row["promoter"]] = float(
                row["activity_pct_wild_type"])
            self.assertEqual(row["cell_system"], "yeast")
        self.assertEqual(len(rows), 88)
        for case in INPUT["cases"]:
            expected = {p: float(case["primary_assay"]["measurements_pct_wt"][p]) for p in PROMOTERS}
            self.assertEqual(from_csv[case["case_id"]], expected, case["case_id"])

    def test_reconciliation_csv_matches_task_input_and_key(self):
        rows = {row["case_id"]: row for row in read_csv("data/source_reconciliation.csv")}
        key_by = {case["case_id"]: case for case in KEY["cases"]}
        for case in INPUT["cases"]:
            row = rows[case["case_id"]]
            self.assertEqual(row["protein_change"], case["protein_change"])
            self.assertEqual(row["cdna_change"], case["cdna_change"])
            self.assertEqual(row["official_nci_detail_url"], case["provenance"]["variant_detail_url"])
            self.assertEqual(float(row["median_pct_wt"]), key_by[case["case_id"]]["median_pct_wt"])
            self.assertEqual(row["recomputed_panel_label"],
                             key_by[case["case_id"]]["protein_assay_label"])

    def test_source_manifest_matches_registry(self):
        manifest = {row["source_id"]: row for row in read_csv("data/source_manifest.csv")}
        registry = {source["source_id"]: source for source in INPUT["source_registry"]}
        self.assertEqual(set(manifest), set(registry))
        for source_id, source in registry.items():
            self.assertEqual(manifest[source_id]["url"], source["url"], source_id)

    def test_r156c_cdna_correction_is_present(self):
        """Regression guard for the documented p.R156C notation correction."""
        case = next(c for c in INPUT["cases"] if c["protein_change"] == "p.R156C")
        self.assertEqual(case["cdna_change"], "c.466C>T")
        self.assertNotIn("465_466delinsTT", json.dumps(INPUT))
        self.assertIn("mut_id=1811", case["provenance"]["variant_detail_url"])

    def test_splice_confounded_case_is_flagged_in_evidence(self):
        """G187S must carry its splice confound in the task-facing packet."""
        case = next(c for c in INPUT["cases"] if c["protein_change"] == "p.G187S")
        note = case["additional_evidence"]["splicing_or_scope_note"].lower()
        self.assertIn("splice", note)
        key = next(c for c in KEY["cases"] if c["case_id"] == case["case_id"])
        self.assertEqual(key["protein_assay_label"], "functionally_preserved")
        self.assertEqual(key["overall_functional_phenotype"], "indeterminate")

    def test_clinical_pathogenicity_absent_from_task_input(self):
        self.assertNotIn("clinical_pathogenicity", json.dumps(INPUT["cases"]))

    def test_key_never_assesses_clinical_pathogenicity(self):
        for case in KEY["cases"]:
            self.assertEqual(case["clinical_pathogenicity"], "not_assessed", case["case_id"])

    def test_bulk_reconciliation_file_exists_and_is_not_marked_complete(self):
        """The provenance gate must stay visibly open until real bytes are compared."""
        rows = read_csv("validation/bulk_reconciliation.csv")
        self.assertEqual(len(rows), 88)
        statuses = {row["match_status"] for row in rows}
        self.assertEqual(statuses, {"not_verified_source_unavailable"})
        for row in rows:
            self.assertEqual(row["observed_value_pct_wt"], "")


class SchemaContractTests(unittest.TestCase):
    """The shipped schemas must actually be executed, not merely documented."""

    def test_task_input_validates_against_its_schema(self):
        schema = json.loads((ROOT / "schemas/task_input.schema.json").read_text(encoding="utf-8"))
        self.assertEqual(validate(INPUT, schema), [])

    def test_reference_submission_validates_against_submission_schema(self):
        schema = json.loads((ROOT / "schemas/submission.schema.json").read_text(encoding="utf-8"))
        submission = json.loads(
            (ROOT / "oracle/reference_submission.json").read_text(encoding="utf-8"))
        self.assertEqual(validate(submission, schema), [])

    def test_submission_template_declares_current_version(self):
        template = json.loads((ROOT / "docs/submission_template.json").read_text(encoding="utf-8"))
        self.assertEqual(template["benchmark_version"], INPUT["benchmark_version"])
        self.assertEqual(template["clinical_pathogenicity"], "not_assessed")

    def test_schema_validator_rejects_a_known_bad_document(self):
        schema = json.loads((ROOT / "schemas/submission.schema.json").read_text(encoding="utf-8"))
        bad = {"benchmark_version": "1.1.0", "clinical_pathogenicity": "pathogenic", "cases": []}
        problems = validate(bad, schema)
        self.assertTrue(any("clinical_pathogenicity" in p for p in problems))
        self.assertTrue(any("minItems" in p for p in problems))


if __name__ == "__main__":
    unittest.main()
