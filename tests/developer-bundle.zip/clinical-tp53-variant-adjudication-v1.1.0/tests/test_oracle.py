"""Oracle tests: threshold boundaries, fail-loud behaviour, and determinism."""
import copy
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "oracle"))
from oracle import (  # noqa: E402
    OracleError, build_reference, compute_median, load_json, panel_label, panel_subclass,
)


class ThresholdTests(unittest.TestCase):
    """Boundaries are inclusive-upper at 20, 75 and 140 per SRC-002."""

    def test_exact_boundaries(self):
        self.assertEqual(panel_label(20), "functionally_abnormal")
        self.assertEqual(panel_label(75), "mixed_or_context_dependent")
        self.assertEqual(panel_label(140), "functionally_preserved")

    def test_just_above_boundaries(self):
        self.assertEqual(panel_label(20.0001), "mixed_or_context_dependent")
        self.assertEqual(panel_label(75.0001), "functionally_preserved")
        self.assertEqual(panel_label(140.0001), "functionally_preserved")

    def test_just_below_boundaries(self):
        self.assertEqual(panel_label(19.9999), "functionally_abnormal")
        self.assertEqual(panel_label(74.9999), "mixed_or_context_dependent")
        self.assertEqual(panel_label(139.9999), "functionally_preserved")

    def test_float_representation_near_boundaries(self):
        """0.1+0.2 style drift must not flip a bin."""
        self.assertEqual(panel_label(0.1 + 0.2 + 19.7), "functionally_abnormal")
        self.assertEqual(panel_label(20 + 1e-12), "mixed_or_context_dependent")
        self.assertEqual(panel_label(75 + 1e-12), "functionally_preserved")

    def test_zero_and_missing_panel(self):
        self.assertEqual(panel_label(0), "functionally_abnormal")
        self.assertEqual(panel_label(None), "indeterminate")

    def test_supertrans_subclass_is_retained_separately(self):
        """Above 140 maps to preserved, but the source subclass is not lost."""
        self.assertEqual(panel_label(180), "functionally_preserved")
        self.assertEqual(panel_subclass(180), "supertrans")
        self.assertEqual(panel_subclass(140), "none")
        self.assertEqual(panel_subclass(140.0001), "supertrans")
        self.assertEqual(panel_subclass(None), "none")

    def test_values_above_100_are_legal_measurements(self):
        """Promoter activity above wild-type is real data, not an error."""
        values = {"WAF1": 162.8, "MDM2": 101.0, "BAX": 99.0, "H1433s": 120.0,
                  "AIP1": 80.0, "GADD45": 95.0, "NOXA": 170.4, "P53R2": 130.1}
        # sorted: 80, 95, 99, 101, 120, 130.1, 162.8, 170.4 -> (101+120)/2
        self.assertEqual(compute_median("T", values), 110.5)
        self.assertEqual(panel_label(110.5), "functionally_preserved")


class MedianTests(unittest.TestCase):
    BASE = {"WAF1": 1, "MDM2": 2, "BAX": 3, "H1433s": 4,
            "AIP1": 5, "GADD45": 6, "NOXA": 7, "P53R2": 8}

    def test_median_of_even_panel_averages_middle_pair(self):
        self.assertEqual(compute_median("T", self.BASE), 4.5)

    def test_key_order_does_not_change_median(self):
        reordered = dict(reversed(list(self.BASE.items())))
        self.assertEqual(compute_median("T", reordered), compute_median("T", self.BASE))

    def test_missing_promoter_rejected(self):
        values = dict(self.BASE)
        del values["WAF1"]
        with self.assertRaisesRegex(OracleError, "expected exactly the eight"):
            compute_median("T", values)

    def test_extra_promoter_rejected(self):
        values = dict(self.BASE, RGC=50)
        with self.assertRaisesRegex(OracleError, "unexpected"):
            compute_median("T", values)

    def test_negative_value_rejected(self):
        with self.assertRaisesRegex(OracleError, "negative"):
            compute_median("T", dict(self.BASE, WAF1=-0.1))

    def test_non_numeric_value_rejected(self):
        with self.assertRaisesRegex(OracleError, "must be a JSON number"):
            compute_median("T", dict(self.BASE, WAF1="12.5"))

    def test_null_value_rejected(self):
        with self.assertRaisesRegex(OracleError, "must be a JSON number"):
            compute_median("T", dict(self.BASE, WAF1=None))

    def test_boolean_value_rejected(self):
        """JSON true is an int in Python; it must not be read as activity 1.0."""
        with self.assertRaisesRegex(OracleError, "must be a JSON number"):
            compute_median("T", dict(self.BASE, WAF1=True))

    def test_non_finite_value_rejected(self):
        with self.assertRaisesRegex(OracleError, "non-finite"):
            compute_median("T", dict(self.BASE, WAF1=float("nan")))
        with self.assertRaisesRegex(OracleError, "non-finite"):
            compute_median("T", dict(self.BASE, WAF1=float("inf")))


class OracleBuildTests(unittest.TestCase):
    def setUp(self):
        self.input_doc = load_json(ROOT / "data/task_input.json")
        self.key_doc = load_json(ROOT / "oracle/reference_answers.json")

    def build(self, input_doc=None, key_doc=None):
        return build_reference(input_doc or self.input_doc, key_doc or self.key_doc)

    def test_reference_has_all_cases(self):
        out = self.build()
        self.assertEqual(len(out["cases"]), 11)
        self.assertEqual(len({c["case_id"] for c in out["cases"]}), 11)

    def test_clinical_pathogenicity_invariant(self):
        out = self.build()
        self.assertEqual(out["clinical_pathogenicity"], "not_assessed")
        for case in out["cases"]:
            self.assertEqual(case["clinical_pathogenicity"], "not_assessed")

    def test_assay_and_overall_labels_are_independent_fields(self):
        """At least one case must disagree, or the two outputs are not separable."""
        out = self.build()
        disagreements = [c for c in out["cases"]
                         if c["protein_assay_label"] != c["overall_functional_phenotype"]]
        self.assertTrue(disagreements)

    def test_case_order_does_not_change_result(self):
        reversed_input = copy.deepcopy(self.input_doc)
        reversed_input["cases"].reverse()
        self.assertEqual(self.build(), self.build(reversed_input))

    def test_key_order_does_not_change_result(self):
        reversed_key = copy.deepcopy(self.key_doc)
        reversed_key["cases"].reverse()
        self.assertEqual(self.build(key_doc=reversed_key), self.build())

    def test_duplicate_input_case_fails(self):
        doc = copy.deepcopy(self.input_doc)
        doc["cases"].append(copy.deepcopy(doc["cases"][0]))
        with self.assertRaisesRegex(OracleError, "Duplicate case_id in input"):
            self.build(doc)

    def test_duplicate_key_case_fails(self):
        key = copy.deepcopy(self.key_doc)
        key["cases"].append(copy.deepcopy(key["cases"][0]))
        with self.assertRaisesRegex(OracleError, "Duplicate case_id in answer key"):
            self.build(key_doc=key)

    def test_missing_key_case_fails(self):
        key = copy.deepcopy(self.key_doc)
        key["cases"].pop()
        with self.assertRaisesRegex(OracleError, "No adjudication key"):
            self.build(key_doc=key)

    def test_extra_key_case_fails(self):
        key = copy.deepcopy(self.key_doc)
        ghost = copy.deepcopy(key["cases"][0])
        ghost["case_id"] = "TP53-999"
        key["cases"].append(ghost)
        with self.assertRaisesRegex(OracleError, "case mismatch"):
            self.build(key_doc=key)

    def test_missing_input_case_fails(self):
        doc = copy.deepcopy(self.input_doc)
        doc["cases"].pop()
        with self.assertRaisesRegex(OracleError, "case mismatch"):
            self.build(doc)

    def test_stale_key_median_fails(self):
        key = copy.deepcopy(self.key_doc)
        key["cases"][0]["median_pct_wt"] += 5
        with self.assertRaisesRegex(OracleError, "disagrees with the value recomputed"):
            self.build(key_doc=key)

    def test_key_label_inconsistent_with_threshold_fails(self):
        key = copy.deepcopy(self.key_doc)
        key["cases"][0]["protein_assay_label"] = "functionally_preserved"
        with self.assertRaisesRegex(OracleError, "disagrees with the threshold rule"):
            self.build(key_doc=key)

    def test_unsupported_label_fails(self):
        key = copy.deepcopy(self.key_doc)
        key["cases"][0]["overall_functional_phenotype"] = "likely_pathogenic"
        with self.assertRaisesRegex(OracleError, "unsupported overall_functional_phenotype"):
            self.build(key_doc=key)

    def test_key_asserting_clinical_pathogenicity_fails(self):
        key = copy.deepcopy(self.key_doc)
        key["cases"][0]["clinical_pathogenicity"] = "pathogenic"
        with self.assertRaisesRegex(OracleError, "out of scope"):
            self.build(key_doc=key)

    def test_key_annotation_mismatch_fails(self):
        """Answer-key DNE fields must mirror the task-input source annotations."""
        key = copy.deepcopy(self.key_doc)
        key["cases"][0]["nci_dne_class"] = "No"
        with self.assertRaisesRegex(OracleError, "does not match the task-input source annotation"):
            self.build(key_doc=key)

    def test_invented_evidence_id_fails(self):
        key = copy.deepcopy(self.key_doc)
        key["cases"][0]["required_evidence_ids"].append("SRC-FABRICATED")
        with self.assertRaisesRegex(OracleError, "unknown sources"):
            self.build(key_doc=key)

    def test_evidence_id_not_declared_in_case_provenance_fails(self):
        key = copy.deepcopy(self.key_doc)
        key["cases"][0]["required_evidence_ids"].append("SRC-001")
        with self.assertRaisesRegex(OracleError, "not declared in this case's provenance"):
            self.build(key_doc=key)

    def test_duplicate_evidence_ids_fail(self):
        key = copy.deepcopy(self.key_doc)
        key["cases"][0]["required_evidence_ids"].append(
            key["cases"][0]["required_evidence_ids"][0])
        with self.assertRaisesRegex(OracleError, "duplicate entries"):
            self.build(key_doc=key)

    def test_missing_key_field_fails(self):
        key = copy.deepcopy(self.key_doc)
        del key["cases"][0]["reference_rationale"]
        with self.assertRaisesRegex(OracleError, "answer key missing fields"):
            self.build(key_doc=key)

    def test_threshold_tampering_fails(self):
        doc = copy.deepcopy(self.input_doc)
        doc["thresholds"]["functionally_abnormal"]["median_lte_pct_wt"] = 19
        with self.assertRaisesRegex(OracleError, "thresholds"):
            self.build(doc)

    def test_version_skew_fails(self):
        key = copy.deepcopy(self.key_doc)
        key["benchmark_version"] = "9.9.9"
        with self.assertRaisesRegex(OracleError, "benchmark versions differ"):
            self.build(key_doc=key)

    def test_non_yeast_cell_system_is_refused(self):
        """A Saos-2 panel must never be scored as the standardized yeast median."""
        doc = copy.deepcopy(self.input_doc)
        doc["cases"][0]["primary_assay"]["cell_system"] = "human_saos2"
        with self.assertRaisesRegex(OracleError, "must be the yeast assay"):
            self.build(doc)

    def test_promoter_panel_tampering_fails(self):
        doc = copy.deepcopy(self.input_doc)
        doc["expected_promoters"] = doc["expected_promoters"][:7]
        with self.assertRaisesRegex(OracleError, "expected_promoters"):
            self.build(doc)


class DeterminismTests(unittest.TestCase):
    def test_in_process_runs_are_equal(self):
        input_doc = load_json(ROOT / "data/task_input.json")
        key_doc = load_json(ROOT / "oracle/reference_answers.json")
        self.assertEqual(build_reference(input_doc, key_doc),
                         build_reference(input_doc, key_doc))

    def test_two_subprocess_runs_are_byte_identical(self):
        with tempfile.TemporaryDirectory() as tmp:
            outputs = []
            for name in ("a.json", "b.json"):
                path = Path(tmp) / name
                subprocess.run([sys.executable, str(ROOT / "oracle/oracle.py"),
                                "--output", str(path)], check=True, capture_output=True)
                outputs.append(path.read_bytes())
            self.assertEqual(outputs[0], outputs[1])

    def test_committed_reference_submission_is_current(self):
        """Guards against a stale checked-in artifact."""
        with tempfile.TemporaryDirectory() as tmp:
            path = Path(tmp) / "ref.json"
            subprocess.run([sys.executable, str(ROOT / "oracle/oracle.py"),
                            "--output", str(path)], check=True, capture_output=True)
            self.assertEqual(
                json.loads(path.read_text(encoding="utf-8")),
                json.loads((ROOT / "oracle/reference_submission.json").read_text(encoding="utf-8")))

    def test_oracle_exits_nonzero_and_prints_error_on_bad_input(self):
        with tempfile.TemporaryDirectory() as tmp:
            bad = Path(tmp) / "bad.json"
            doc = load_json(ROOT / "data/task_input.json")
            doc["cases"][0]["primary_assay"]["measurements_pct_wt"]["WAF1"] = -5
            bad.write_text(json.dumps(doc), encoding="utf-8")
            result = subprocess.run([sys.executable, str(ROOT / "oracle/oracle.py"),
                                     "--input", str(bad)], capture_output=True, text=True)
            self.assertEqual(result.returncode, 2)
            self.assertIn("ORACLE_ERROR", result.stderr)
            self.assertEqual(result.stdout, "")

    def test_oracle_makes_no_network_calls(self):
        """Socket creation inside the Oracle would break the offline guarantee."""
        import socket

        original = socket.socket

        def forbidden(*args, **kwargs):
            raise AssertionError("Oracle attempted to open a socket")

        socket.socket = forbidden
        try:
            build_reference(load_json(ROOT / "data/task_input.json"),
                            load_json(ROOT / "oracle/reference_answers.json"))
        finally:
            socket.socket = original


if __name__ == "__main__":
    unittest.main()
