"""Packaging tests: solver-archive secrecy, ZIP integrity, and build determinism."""
import json
import subprocess
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "scripts"))
from audit_solver_bundle import audit  # noqa: E402

KEY = json.loads((ROOT / "oracle/reference_answers.json").read_text(encoding="utf-8"))


def build(outdir):
    result = subprocess.run(
        [sys.executable, str(ROOT / "scripts/build_solver_bundle.py"), "--outdir", str(outdir)],
        capture_output=True, text=True)
    if result.returncode != 0:
        raise AssertionError(f"build failed: {result.stderr}")
    solver = next(Path(outdir).glob("*-solver-only.zip"))
    developer = next(Path(outdir).glob("*-developer.zip"))
    return solver, developer


class SolverBundleTests(unittest.TestCase):
    def setUp(self):
        self._tmp = tempfile.TemporaryDirectory()
        self.solver, self.developer = build(self._tmp.name)

    def tearDown(self):
        self._tmp.cleanup()

    def names(self, archive_path):
        with zipfile.ZipFile(archive_path) as archive:
            return [n.split("/", 1)[1] for n in archive.namelist()]

    def test_solver_archive_excludes_oracle_key_and_reference(self):
        names = self.names(self.solver)
        for name in names:
            self.assertFalse(name.startswith("oracle/"), name)
            self.assertFalse(name.startswith("verifier/"), name)
            self.assertFalse(name.startswith("tests/"), name)
            self.assertFalse(name.startswith("curation/"), name)
            self.assertFalse(name.startswith("validation/"), name)
        self.assertNotIn("docs/reference_submission_example.json", names)

    def test_solver_archive_contains_what_a_solver_needs(self):
        names = self.names(self.solver)
        for required in ("instruction.md", "data/task_input.json",
                         "schemas/submission.schema.json", "docs/submission_template.json"):
            self.assertIn(required, names)

    def test_solver_archive_preserves_the_task_instruction_verbatim(self):
        with zipfile.ZipFile(self.solver) as archive:
            name = next(n for n in archive.namelist() if n.endswith("instruction.md"))
            text = archive.read(name).decode("utf-8")
        self.assertIn(
            "You have 28800 seconds to complete the analysis. "
            "Do not use online solutions or task-specific external hints.",
            text)

    def test_solver_archive_leaks_no_gold_labels(self):
        self.assertEqual(audit(self.solver), [])

    def test_developer_archive_does_contain_the_key(self):
        """Negative control: the audit must be capable of detecting leakage."""
        names = self.names(self.developer)
        self.assertIn("oracle/reference_answers.json", names)
        self.assertNotEqual(audit(self.developer), [])

    def test_no_overall_label_recoverable_from_solver_archive(self):
        """Structural check: no object in the archive pairs a case with its label."""
        from audit_solver_bundle import _proximity_leak, _structural_leak
        with zipfile.ZipFile(self.solver) as archive:
            blobs = {n: archive.read(n) for n in archive.namelist()}
        for case in KEY["cases"]:
            for field in ("overall_functional_phenotype", "protein_assay_label"):
                for name, blob in blobs.items():
                    structural = _structural_leak(blob, case["case_id"], case[field])
                    leaked = structural if structural is not None else _proximity_leak(
                        blob, case["case_id"], case[field])
                    self.assertFalse(leaked, f"{case['case_id']} {field} leaked in {name}")

    def test_leak_detector_catches_a_planted_leak(self):
        """Negative control for the detector itself, not just for the archive."""
        from audit_solver_bundle import _structural_leak
        planted = json.dumps({"cases": [{"case_id": "TP53-001",
                                         "answer": "functionally_abnormal"}]}).encode()
        self.assertTrue(_structural_leak(planted, "TP53-001", "functionally_abnormal"))
        self.assertFalse(_structural_leak(planted, "TP53-002", "functionally_abnormal"))

    def test_zip_integrity(self):
        for archive_path in (self.solver, self.developer):
            with zipfile.ZipFile(archive_path) as archive:
                self.assertIsNone(archive.testzip(), archive_path.name)

    def test_no_unsafe_member_paths(self):
        for archive_path in (self.solver, self.developer):
            with zipfile.ZipFile(archive_path) as archive:
                for name in archive.namelist():
                    self.assertFalse(name.startswith("/"), name)
                    self.assertNotIn("..", Path(name).parts, name)

    def test_developer_archive_excludes_bytecode(self):
        for name in self.names(self.developer):
            self.assertFalse(name.endswith(".pyc"), name)
            self.assertNotIn("__pycache__", name)

    def test_builds_are_byte_identical(self):
        with tempfile.TemporaryDirectory() as other:
            solver2, developer2 = build(other)
            self.assertEqual(self.solver.read_bytes(), solver2.read_bytes())
            self.assertEqual(self.developer.read_bytes(), developer2.read_bytes())

    def test_build_does_not_modify_the_working_tree(self):
        """The pre-1.1.0 builder rewrote README_solver.md as a side effect."""
        before = (ROOT / "README_solver.md").read_bytes()
        with tempfile.TemporaryDirectory() as other:
            build(other)
        self.assertEqual((ROOT / "README_solver.md").read_bytes(), before)


if __name__ == "__main__":
    unittest.main()
