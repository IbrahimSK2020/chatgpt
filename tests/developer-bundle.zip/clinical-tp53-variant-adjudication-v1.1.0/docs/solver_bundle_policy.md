# Solver-only bundle policy

A scored task-solver package must include `instruction.md`,
`data/task_input.json`, `schemas/submission.schema.json`,
`schemas/task_input.schema.json`, `docs/submission_template.json`,
`README_solver.md` and `LICENSE_AND_ATTRIBUTION.md`.

It must **exclude** `oracle/` (answer key and reference submission), `verifier/`,
`tests/`, `curation/` (decision log and reconciliation notes), `validation/`,
`scripts/`, `README.md`, `CHANGELOG.md`, `docs/human_review_rubric.md`,
`docs/blinded_review_worksheet.csv`, `data/source_reconciliation.csv` and
`data/promoter_activities.csv`. The developer bundle may contain all of these.

## Build and audit

```bash
python3 scripts/build_solver_bundle.py --outdir ../dist
python3 scripts/audit_solver_bundle.py ../dist/<name>-solver-only.zip
```

The builder is deterministic (fixed ZIP timestamps, sorted members) and has no
working-tree side effects, so two builds of an unchanged tree are byte-identical
and their SHA-256 values can be published.

## The audit is a gate, not a formality

`audit_solver_bundle.py` exits non-zero on any finding. It checks ZIP integrity,
rejects absolute and traversing member paths, rejects forbidden path components,
scans for key-internal tokens, and performs a **structural** per-JSON-object
check that no object associates a `case_id` with its gold label (with proximity
matching for non-JSON members).

Output field names such as `overall_functional_phenotype` are deliberately *not*
treated as leakage: the solver must be told the shape of the submission, so
those names appear legitimately in the schema and instruction. An audit that
fires on every build teaches operators to ignore it.

The detector is validated by two negative controls in the test suite: a planted
synthetic leak must be caught, and the developer archive — which really does
contain the key — must fail the audit.

**Neither script is a security boundary.** Inspect archive contents before any
release; do not assume tooling substitutes for review.
