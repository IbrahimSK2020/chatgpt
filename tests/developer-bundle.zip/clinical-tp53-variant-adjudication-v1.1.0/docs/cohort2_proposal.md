# Cohort 2 design proposal (not yet populated)

## Why the current cohort is inadequate

Measured properties of the v1.1.0 cohort (computed, not estimated):

| Property | Value |
|---|---|
| Cases | 11 |
| Canonical hotspot cases | 6 (TP53-001…006) |
| Cases where both label axes agree | 9 of 11 |
| Medians ≤ 9.15% WT | 6 |
| Medians in 20–75% band | 2 |
| Medians > 75% | 3 |
| Cases with median within ±5 points of the 20% boundary | **0** |
| Cases with median > 140% (supertrans) | **0** |
| Cases with a genuine evidence confound | 1 (TP53-010) |
| Cases with incomplete panels | **0** |

Two consequences follow. First, a solver that emits `functionally_abnormal`
whenever it recognises a hotspot codon scores 6/11 on the overall axis without
performing the adjudication — the exact shortcut `instruction.md` forbids and
that no current test detects at the cohort level. Second, the threshold logic
is never stressed by real data: every boundary and supertrans test is synthetic.

## Target composition for cohort 2 (n ≈ 40)

| Stratum | Target n | What it tests | Current n |
|---|---:|---|---:|
| Non-hotspot missense, clearly abnormal | 6 | abnormality without hotspot cueing | 0 |
| Non-hotspot missense, clearly preserved | 6 | preserved call without polymorphism cueing | 0 |
| Median within ±5 points of 20% | 4 | the abnormal/mixed boundary | 0 |
| Median within ±5 points of 75% | 4 | the mixed/preserved boundary | 1 (78.7) |
| Median > 140% (supertrans) | 3 | the collapsed-label decision, D-03 | 0 |
| High promoter discordance (spread > 100 points) | 4 | heterogeneity vs median summary | 1 |
| Splice-confounded, protein panel preserved | 4 | protein-only evidence must not close the case | 1 |
| Incomplete panel (<8 promoters) | 3 | `indeterminate`; must not be imputed | 0 |
| Conflicting yeast vs Saos-2 evidence | 4 | cross-system pooling refusal (D-06) | 0 |
| DNE/LOF discordant with transactivation | 3 | annotations are copied, not inferred | 0 |
| Validated polymorphism with reduced activity | 3 | polymorphism status is not a functional result | 0 |

Hotspot cases should be capped at roughly 15% of the cohort, with the current
six retained as anchors.

## Hard constraints on populating it

1. **No fabricated biology.** Every case must carry a real variant identity and
   real measurements traced to a checksummed official file. Synthetic values are
   permitted **only** as software-test fixtures in `tests/`, never in
   `data/`, and must be obviously non-biological where possible.
2. **Source first.** D-04 must be cleared before any case is added. Adding cases
   on top of an unreconciled base multiplies the unverified surface.
3. **Review before freeze.** Each new case needs a completed blinded review
   (`docs/blinded_review_worksheet.csv`) before entering the key.
4. **Incomplete panels stay incomplete.** The `indeterminate` stratum exists to
   test that missing values are not imputed. The Oracle must be extended to emit
   `indeterminate` for a short panel rather than rejecting the case outright —
   `panel_label(None)` already returns it, but `compute_median` currently
   rejects a short panel, so this is a required code change for cohort 2.
5. **Blind the strata.** Stratum membership is a label hint and must live in the
   developer bundle only, never in `data/task_input.json`.

## Measurable release gates

A release may claim scientific readiness only when **all** of the following hold.
Each is objectively checkable.

| Gate | Criterion | Current |
|---|---|---|
| G1 Provenance | 100% of promoter values reconciled against a SHA-256-identified official file; checksum recorded | **FAIL** (0%) |
| G2 Identity | 100% of variant identities confirmed against `MutationView_r21.csv` | **FAIL** (0%) |
| G3 Independent review | 100% of overall labels adjudicated by ≥1 qualified reviewer, blinded; disagreements logged with resolutions | **FAIL** (0 of 11) |
| G4 Reproducibility | Oracle byte-identical across runs; reference submission regenerable; builds byte-identical | **PASS** |
| G5 Verifier independence | No Oracle import; medians recomputed independently; enforced by test | **PASS** |
| G6 Adversarial coverage | Every failure mode in `instruction.md` §7 has ≥1 test; all pass | **PASS** (124 tests) |
| G7 Leakage | Solver archive passes the leakage audit; detector validated by a planted-leak control | **PASS** |
| G8 Coverage | ≥30 cases, hotspots ≤20%, every stratum above non-empty | **FAIL** (11 cases, 55% hotspot) |
| G9 Discrimination | A hotspot-only heuristic scores < 40% on the overall axis | **FAIL** (scores ~55%) |
| G10 Terms | Upstream redistribution terms re-checked and attribution recorded | **FAIL** (not re-checked) |

**G1, G2, G3, G8, G9 and G10 are currently failing.** Technical completion
(G4–G7) is achieved; scientific release readiness is not.
