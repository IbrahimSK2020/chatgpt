# Human review rubric for overall functional phenotype

This rubric is for a qualified independent reviewer. Review the supplied raw evidence without seeing the current overall label or rationale first. The primary yeast panel class is computed mechanically and should not be used as a proxy for clinical pathogenicity.

## Required review fields per case

- Reviewer ID/qualification and review date.
- Confirmed variant identity and transcript/cDNA/protein notation.
- Confirmation of all eight promoter values against the cited source.
- Independent median and primary assay bin.
- Assay model, endpoint, and limitations.
- Whether there is credible evidence for partial function, promoter-specific effects, splice alteration, or conflict among distinct assay systems.
- Overall phenotype: `functionally_abnormal`, `functionally_preserved`, `mixed_or_context_dependent`, or `indeterminate`.
- Confidence and evidence supporting/limiting the conclusion.
- Whether the previous adjudication agrees, disagrees, or cannot be resolved.
- Written reason for any proposed change; no forced consensus.

## Label guidance

- `functionally_abnormal`: evidence consistently supports substantially impaired function in the specified functional context.
- `functionally_preserved`: evidence supports retained function in the evaluated contexts, with no major unresolved confound in the evidence packet.
- `mixed_or_context_dependent`: partial residual activity, promoter-specific heterogeneity, or meaningful assay-context differences prevent a simple global label.
- `indeterminate`: missing, conflicting, or confounded evidence prevents a defensible overall functional conclusion.

## Prohibited shortcuts

Do not use cancer hotspot status, tumor recurrence, an in-silico score, or a clinical database classification as a substitute for functional evidence. Do not infer gain-of-function from loss of function or DNE. Do not infer clinical pathogenicity from this functional benchmark.

## Reviewer decision sheet template

| Case ID | Variant identity confirmed? | 8 values checked? | Independent median | Primary assay label | Overall label | Confidence | Agree/disagree/unresolved | Evidence IDs | Rationale |
|---|---|---|---:|---|---|---|---|---|---|

---

# Blinded review procedure (added v1.1.0)

## How to run the review

1. Open `docs/blinded_review_worksheet.csv`. It contains, per case, the variant
   identity, all eight promoter values, promoter min/max and the count below
   75% WT, the assay and cell system, the NCI source annotations, the evidence
   notes, and the source URL. It contains **no** prior label, median, or
   rationale — the blinding is enforced by
   `tests/test_data_integrity.py` and was verified at generation time.
2. Do **not** open `oracle/reference_answers.json`, `oracle/reference_submission.json`,
   `curation/decision_log.md`, or `data/source_reconciliation.csv` before
   completing your entries. Those contain the prior adjudication.
3. Fill every reviewer column. Compute the median yourself.
4. Only then compare against the prior key and record agreement or disagreement.

## Structured rubric

For each case, answer in order. Stop and record `indeterminate` at any point
where the evidence does not support going further.

**Step 1 — Identity.** Does the transcript/cDNA/protein notation agree with the
cited source? If it cannot be checked, mark identity unconfirmed and say so.

**Step 2 — Panel completeness.** Are all eight promoter values present and
attributable to the *yeast* assay? A partial panel yields `indeterminate` for
the assay axis; do not impute.

**Step 3 — Assay bin.** Compute the median. Apply ≤20 / >20–75 / >75–140 / >140.
This step is mechanical and should not be influenced by the variant's identity
or reputation.

**Step 4 — Heterogeneity.** Inspect the spread, not just the median. Record
explicitly whether promoter-specific variation is wide enough that the median
misrepresents the panel. Two worked examples in this cohort: TP53-008 spans
34.7–162.8 (spread 128.1) and TP53-009 has two promoters below 75% despite a
median of 93.6.

**Step 5 — Confounds.** Is there credible evidence of a splice effect, a
different cell system, or a conflicting assay? If a protein-only panel looks
preserved while a transcript-level confound is flagged, the protein result does
**not** close the case.

**Step 6 — Evidence quality of any conflicting claim.** If you are about to let
conflicting evidence override a complete, source-identified panel, first confirm
that the conflicting evidence has an identifiable source row, cell system and
reference. An unattributed narrative summary is not sufficient. (This is the
live question for TP53-011; see D-09.)

**Step 7 — Overall label.** Choose `functionally_abnormal`,
`functionally_preserved`, `mixed_or_context_dependent`, or `indeterminate`.
`indeterminate` is a legitimate scientific result, not a failure to decide. Do
not force a definitive call.

**Step 8 — Confidence, reported separately.** Rate confidence in the assay bin
and in the overall adjudication as two distinct judgements. They routinely differ.

## Disagreement handling

Record disagreements; do not resolve them by deferring to the existing key.
Where two reviewers disagree and neither can be shown wrong from the evidence
packet, the case is `indeterminate` pending better evidence, and that outcome is
recorded rather than averaged away.

## Prohibited shortcuts (restated)

Hotspot status, tumour recurrence counts, in-silico scores, and clinical
database assertions are **not** functional measurements. Do not infer DNE, LOF,
or gain-of-function from the transactivation median. Do not infer clinical
pathogenicity from anything in this benchmark.
