# TP53 Functional Adjudication — solver package

Read `instruction.md`, then adjudicate the 11 cases in `data/task_input.json`.

Your submission must conform to `schemas/submission.schema.json`;
`docs/submission_template.json` is a blank starting point.

Use only the supplied evidence packet and its stated source annotations. Report
exactly one case object per supplied `case_id` — no additions, no omissions.
Missing values stay missing; do not invent data.

This task adjudicates **functional evidence only**. It does not assign clinical
pathogenicity: `clinical_pathogenicity` must be `not_assessed` at the top level
and in every case. No answer key is included in this package.
