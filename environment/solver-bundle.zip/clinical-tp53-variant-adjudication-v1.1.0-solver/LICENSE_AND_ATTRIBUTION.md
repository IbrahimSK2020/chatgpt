# Attribution and reuse note

This package is a small derived curation of selected fields and functional assay values displayed by the NCI TP53 Database and a secondary evidence summary from ClinVar. The package includes source links and access dates.

Do not assume that every upstream source has the same redistribution terms. Before public benchmark release, check the current NCI TP53 Database and ClinVar terms, provide required attribution, and document any constraints. This pilot is intended for research/benchmark development and is not for clinical decision-making.

No clinical diagnosis, clinical pathogenicity classification, or patient-specific medical advice is provided.
