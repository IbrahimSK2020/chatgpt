# Known limitations — v1.0.0

1. **Bulk-file audit open.** The 88 values and 11 variant identities were reconciled against official NCI variant-detail pages, but not yet compared to a checksum-identified bulk R21 download.
2. **Overall labels provisional.** Current overall functional phenotype labels reflect one provisional curator and require independent qualified review.
3. **Small biased pilot.** Eleven cases are insufficient for broad benchmark claims and overrepresent familiar variants.
4. **Automated rationale limits.** The verifier checks evidence IDs and minimum rationale structure, not the semantic truth of prose.
5. **No clinical classification.** Clinical pathogenicity is not assessed. This is not clinical decision-support software.
6. **NCI annotations are context-specific.** DNE and DNE/LOF fields are copied from the source; they are not inferred from the yeast median.
7. **Snapshot freshness.** NCI R21 is the upstream data release identified for this pilot; web pages can be updated independently. Access dates and URLs are retained.
