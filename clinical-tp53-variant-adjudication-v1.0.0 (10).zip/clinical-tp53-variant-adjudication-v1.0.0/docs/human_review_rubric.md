# Human review rubric for overall functional phenotype

This rubric is for a qualified independent reviewer. Review the supplied raw evidence without seeing the current overall label or rationale first. The primary yeast panel class is computed mechanically and should not be used as a proxy for clinical pathogenicity.

## Required review fields per case

- Reviewer ID/qualification and review date.
- Confirmed variant identity and transcript/cDNA/protein notation.
- Confirmation of all eight promoter values against the cited source.
- Independent median and primary assay bin.
- Assay model, endpoint, and limitations.
- Whether there is credible evidence for partial function, promoter-specific effects, splice alteration, or conflict among distinct assay systems.
- Overall phenotype: `functionally_abnormal`, `functionally_preserved`, `mixed_or_context_dependent`, or `indeterminate`.
- Confidence and evidence supporting/limiting the conclusion.
- Whether the previous adjudication agrees, disagrees, or cannot be resolved.
- Written reason for any proposed change; no forced consensus.

## Label guidance

- `functionally_abnormal`: evidence consistently supports substantially impaired function in the specified functional context.
- `functionally_preserved`: evidence supports retained function in the evaluated contexts, with no major unresolved confound in the evidence packet.
- `mixed_or_context_dependent`: partial residual activity, promoter-specific heterogeneity, or meaningful assay-context differences prevent a simple global label.
- `indeterminate`: missing, conflicting, or confounded evidence prevents a defensible overall functional conclusion.

## Prohibited shortcuts

Do not use cancer hotspot status, tumor recurrence, an in-silico score, or a clinical database classification as a substitute for functional evidence. Do not infer gain-of-function from loss of function or DNE. Do not infer clinical pathogenicity from this functional benchmark.

## Reviewer decision sheet template

| Case ID | Variant identity confirmed? | 8 values checked? | Independent median | Primary assay label | Overall label | Confidence | Agree/disagree/unresolved | Evidence IDs | Rationale |
|---|---|---|---:|---|---|---|---|---|---|
