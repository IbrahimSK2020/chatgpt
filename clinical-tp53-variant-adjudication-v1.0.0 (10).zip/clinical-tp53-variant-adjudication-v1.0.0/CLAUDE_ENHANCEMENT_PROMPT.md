# Claude Enhancement Brief — TP53 Scientific Benchmark

You are acting as a senior bioinformatics engineer, molecular oncology scientist, and benchmark QA reviewer. Improve this repository rigorously; do not merely make cosmetic edits. The current build includes an Oracle and verifier, but the source audit and overall phenotype key are explicitly provisional.

## Non-negotiable rules

- Never claim a second expert review occurred unless a qualified human actually performed it.
- Never claim bulk-file reconciliation unless you retrieved the official files, recorded SHA-256 checksums, and compared every curated row/value against them.
- Do not change labels just to make tests pass. Record evidence, disagreements, and proposed changes in a versioned discrepancy log.
- Keep the three outputs separate: (1) standardized eight-promoter yeast assay bin, (2) overall functional phenotype, (3) clinical pathogenicity. Clinical pathogenicity is out of scope and must remain `not_assessed`.
- Do not pool functional assays from different cell systems or experimental designs into the standardized yeast median.
- Do not infer DNE, LOF, or gain-of-function from hotspot status, cancer occurrence, or in-silico predictions alone.
- Do not invent missing values, assay references, variant identities, or clinical interpretations.
- Keep the runtime deterministic and offline after the evidence packet is frozen. Use Python standard library unless a dependency is essential and justified.
- Preserve the task instruction sentence exactly: “You have 28800 seconds to complete the analysis. Do not use online solutions or task-specific external hints.”

## Required work, in order

### 1. Inventory and baseline
1. Inspect all files and explain the data flow from task input to Oracle to verifier.
2. Run every existing command and test. Save the exact commands, exit codes, stdout/stderr, and environment/Python version.
3. Check the ZIP/package integrity, schema validity, case counts, promoter counts, duplicate IDs, missing values, and all source IDs.
4. Do not say a test passed unless you actually ran it and recorded the result.

### 2. Official-source reconciliation
1. Start from the official NCI TP53 Database R21 download page and official user manual in `sources.md`.
2. Retrieve the relevant R21 functional/structural and systematic yeast assay downloads if accessible. Record filename, official URL, access date, byte size, SHA-256 checksum, and any reuse/attribution terms.
3. Compare all 11 variants and all 88 promoter values against the downloaded data, using stable identifiers and exact promoter columns. Check transcript HGVS identity as well as protein name; p.R156C has a documented cDNA-notation correction in v0.1.1 and should be specifically rechecked.
4. Preserve source-page and bulk-file evidence separately. If a value is not present in a bulk file, do not force a match; explain how the page and bulk dataset differ.
5. Produce `validation/bulk_reconciliation.csv` with one row per case/promoter and columns for expected, observed, match status, source row/key, and notes. Add an aggregate report and hashes. If network access is unavailable, state that explicitly and leave this gate open.

### 3. Independent scientific adjudication
1. Recompute all eight-promoter medians independently from raw measurements and verify each threshold boundary.
2. Review the overall functional phenotype independently of the stored provisional labels. Consider promoter heterogeneity, context-specific assays, possible splicing effects, and what the cited experiments actually measured.
3. Create a blind adjudication sheet that does not expose the previous overall label/rationale to the reviewer. Provide the evidence packet and a rubric.
4. Mark uncertain cases as `indeterminate` or `mixed_or_context_dependent` where the supplied evidence does not support a crisp conclusion. Do not force binary classes.
5. Record every disagreement and resolution in a signed/dated reviewer log. Until a qualified second reviewer has actually completed the review, keep the key labelled provisional.
6. Distinguish assay-derived confidence from overall-evidence confidence. Explain the limits of each.

### 4. Oracle quality
1. The Oracle must deterministically emit the schema-conformant reference output from the frozen task packet and adjudication key.
2. Ensure it fails loudly on missing/extra promoters, duplicate case IDs, non-numeric or negative values, missing keys, mismatched key medians, and inconsistent thresholds.
3. It must not access the network, read arbitrary environment state, or silently substitute values.
4. Keep the answer key outside the task-solver bundle. Add a separate command that builds a solver-only package with no `oracle/`, no answer key, and no reference submission.
5. Include a reproducibility test proving that two oracle runs produce byte-identical output.

### 5. Verifier quality
1. Keep verifier logic independent from Oracle implementation; do not import Oracle functions.
2. Verify schema, exact case coverage, duplicate/unknown IDs, enum values, medians independently recalculated from task input, both labels, source annotation fidelity, required evidence IDs, and the clinical-pathogenicity boundary.
3. Test malformed JSON, missing case, duplicate case, extra case, incorrect median, threshold-boundary changes, swapped labels, missing evidence IDs, invented source IDs, wrong DNE/LOF fields, unsupported clinical pathogenicity, and excessively short rationales.
4. Output machine-readable JSON with score breakdown, errors, and explicit caveat that free-text rationale semantics are not automatically proven.
5. Do not award full credit for label correctness alone if evidence provenance or the clinical boundary is violated.

### 6. Scientific adversarial tests
Add unit and property-style tests for:
- threshold boundaries 20, just above 20, 75, just above 75, 140, and just above 140;
- row-order invariance;
- exact eight-promoter set and no duplicates;
- missing and malformed measurements;
- values above 100% being allowed;
- no pooling of Saos2/human-cell assays into yeast medians;
- splice-confounded case not being forced to overall preserved solely by a protein-only panel;
- DNE/LOF being copied only from documented source fields;
- output never assigning clinical pathogenicity.

### 7. Benchmark design and difficulty
1. Assess whether the current 11 cases are balanced or too dominated by canonical hotspot variants. State limitations honestly.
2. Propose a second cohort with non-hotspot variants, borderline medians, promoter-specific discordance, splice-confounded cases, missing evidence, and genuinely conflicting assay contexts.
3. Add new cases only after sourcing and review; do not synthesize fake measurements and call them real. Synthetic cases may be added only as clearly labelled software unit-test fixtures, not biological gold labels.
4. Define a reviewer rubric and minimum release gates for expert review, provenance, and reproducibility.

### 8. Deliverables
- Updated `README.md` with architecture and exact run commands.
- `validation/bulk_reconciliation.csv` and report, or an explicit documented blocker if download is not possible.
- Improved Oracle, verifier, JSON schemas, and comprehensive tests.
- `docs/human_review_rubric.md` and a blank independent review template.
- `validation/test_results.txt` containing actual executed results.
- `validation/known_limitations.md`.
- `CHANGELOG.md` and incremented version number for material changes.
- A solver-only package that excludes all answer keys, plus a developer package that includes the Oracle/key.
- Final concise report separating completed work, test evidence, source gaps, scientific disagreements, and remaining release blockers.

## Definition of done
The build is technically complete only when the Oracle, independent verifier, tests, and solver-only package work. The dataset is scientifically release-ready only after bulk-source reconciliation and independent qualified review. Do not conflate these two statuses.
