#!/usr/bin/env python3
"""Independent verifier and scorer for the TP53 functional-adjudication pilot.

The verifier does not import the Oracle. It recomputes medians from task input and compares
objective outputs to a frozen, explicitly provisional reference key. Free-text rationale
semantics are not proven by this program and require human review.
"""
from __future__ import annotations
import argparse
import json
import math
import statistics
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "data" / "task_input.json"
KEY = ROOT / "oracle" / "reference_answers.json"
LABELS = {"functionally_abnormal", "functionally_preserved", "mixed_or_context_dependent", "indeterminate"}
DNE = {"Yes", "Moderate", "No", "NA", "Not reported", "Indeterminate"}
DNE_LOF = {"DNE_LOF", "notDNE_notLOF", "notDNE_LOF", "unclass", "NA", "Indeterminate"}
POLYMORPHISM = {"Yes", "No"}
PROMOTERS = {"WAF1", "MDM2", "BAX", "H1433s", "AIP1", "GADD45", "NOXA", "P53R2"}
TOL = 1e-4
TOP_REQUIRED = {"benchmark_version", "clinical_pathogenicity", "cases"}
TOP_ALLOWED = TOP_REQUIRED | {"benchmark_id", "status"}
CASE_REQUIRED = {
    "case_id", "median_pct_wt", "protein_assay_label", "overall_functional_phenotype",
    "nci_dne_class", "nci_dne_lof_class", "validated_polymorphism", "clinical_pathogenicity",
    "evidence_ids", "rationale", "confidence"
}
CASE_ALLOWED = CASE_REQUIRED
EXPECTED_THRESHOLDS = {
    "functionally_abnormal": {"median_lte_pct_wt": 20},
    "mixed_or_context_dependent": {"median_gt_pct_wt": 20, "median_lte_pct_wt": 75},
    "functionally_preserved": {"median_gt_pct_wt": 75, "median_lte_pct_wt": 140},
    "supertrans_subclass": {"median_gt_pct_wt": 140},
    "missing_panel": "indeterminate",
}


def load(path):
    with Path(path).open(encoding="utf-8") as f:
        return json.load(f)


def add_error(errors, case_id, field, message):
    errors.append({"case_id": case_id, "field": field, "error": message})


def verify(submission, input_doc, key_doc):
    errors = []
    if not isinstance(submission, dict):
        return {"status": "FAIL", "score": 0, "max_score": 100, "errors": [{"field": "root", "error": "submission must be a JSON object"}], "score_breakdown_by_case": {}}

    extra_top = set(submission) - TOP_ALLOWED
    missing_top = TOP_REQUIRED - set(submission)
    if extra_top:
        add_error(errors, "__root__", "schema", f"unexpected top-level fields: {sorted(extra_top)}")
    if missing_top:
        add_error(errors, "__root__", "schema", f"missing required top-level fields: {sorted(missing_top)}")
    if submission.get("benchmark_version") != input_doc.get("benchmark_version"):
        add_error(errors, "__root__", "benchmark_version", "missing or incorrect benchmark_version")
    if "benchmark_id" in submission and submission.get("benchmark_id") != input_doc.get("benchmark_id"):
        add_error(errors, "__root__", "benchmark_id", "incorrect benchmark_id")
    if "status" in submission and submission.get("status") != "provisional_curated_pilot_not_expert_panel_gold_standard":
        add_error(errors, "__root__", "status", "unexpected status string")
    if submission.get("clinical_pathogenicity") != "not_assessed":
        add_error(errors, "__root__", "clinical_pathogenicity", "must be exactly 'not_assessed'; this benchmark does not classify clinical pathogenicity")
    if input_doc.get("thresholds") != EXPECTED_THRESHOLDS:
        add_error(errors, "__input__", "thresholds", "task input thresholds differ from the documented assay thresholds")

    candidate_cases = submission.get("cases")
    if not isinstance(candidate_cases, list):
        add_error(errors, "__root__", "cases", "must be a list")
        candidate_cases = []
    input_by = {c["case_id"]: c for c in input_doc["cases"]}
    key_by = {c["case_id"]: c for c in key_doc["cases"]}
    cand_by = {}
    for i, case in enumerate(candidate_cases):
        if not isinstance(case, dict):
            add_error(errors, f"row-{i}", "case", "each cases element must be an object")
            continue
        cid = case.get("case_id")
        if not isinstance(cid, str):
            add_error(errors, f"row-{i}", "case_id", "must be a string")
            continue
        if cid in cand_by:
            add_error(errors, cid, "case_id", "duplicate case_id")
        else:
            cand_by[cid] = case
        if cid not in input_by:
            add_error(errors, cid, "case_id", "unknown case_id")
        missing_fields = CASE_REQUIRED - set(case)
        extra_fields = set(case) - CASE_ALLOWED
        if missing_fields:
            add_error(errors, cid, "schema", f"missing fields: {sorted(missing_fields)}")
        if extra_fields:
            add_error(errors, cid, "schema", f"unexpected fields: {sorted(extra_fields)}")

    if len(candidate_cases) != len(input_by):
        add_error(errors, "__root__", "case_count", f"expected exactly {len(input_by)} cases, received {len(candidate_cases)}")
    for cid in sorted(set(input_by) - set(cand_by)):
        add_error(errors, cid, "case_id", "missing required case")

    # 100 objective points per expected case: 30 + 30 + 15 + 5 + 10 + 5 + 5.
    points_possible = max(1, len(input_by) * 100)
    points_earned = 0
    per_case = {}
    known_source_ids = {s["source_id"] for s in input_doc.get("source_registry", [])}

    for cid, inp in input_by.items():
        candidate = cand_by.get(cid)
        key = key_by.get(cid)
        breakdown = {"panel_label": 0, "overall_label": 0, "median": 0, "source_annotations": 0, "evidence": 0, "clinical_boundary": 0, "rationale_shape": 0}
        if not isinstance(candidate, dict) or key is None:
            per_case[cid] = breakdown
            continue

        panel = candidate.get("protein_assay_label")
        if panel not in LABELS:
            add_error(errors, cid, "protein_assay_label", "invalid or missing label")
        elif panel == key["protein_assay_label"]:
            breakdown["panel_label"] = 30
        else:
            add_error(errors, cid, "protein_assay_label", f"expected {key['protein_assay_label']}, received {panel}")

        overall = candidate.get("overall_functional_phenotype")
        if overall not in LABELS:
            add_error(errors, cid, "overall_functional_phenotype", "invalid or missing label")
        elif overall == key["overall_functional_phenotype"]:
            breakdown["overall_label"] = 30
        else:
            add_error(errors, cid, "overall_functional_phenotype", f"expected provisional reference {key['overall_functional_phenotype']}, received {overall}")

        measurements = inp["primary_assay"]["measurements_pct_wt"]
        if set(measurements) != PROMOTERS:
            add_error(errors, cid, "task_input", "source panel must contain exactly the eight expected named promoters")
        else:
            try:
                values = [float(measurements[p]) for p in PROMOTERS]
                if any(not math.isfinite(v) or v < 0 for v in values):
                    raise ValueError("measurements must be finite, non-negative numbers")
                median = statistics.median(values)
                submitted = candidate.get("median_pct_wt")
                if isinstance(submitted, (int, float)) and not isinstance(submitted, bool) and math.isfinite(float(submitted)) and abs(float(submitted) - median) <= TOL:
                    breakdown["median"] = 15
                else:
                    add_error(errors, cid, "median_pct_wt", f"must equal independently recomputed median {median:.6f} within tolerance {TOL}")
                if abs(float(key["median_pct_wt"]) - median) > TOL:
                    add_error(errors, cid, "reference_key", "frozen reference median disagrees with task input; stop evaluation and investigate")
            except (TypeError, ValueError) as exc:
                add_error(errors, cid, "median_pct_wt", f"invalid source measurements: {exc}")

        ann = inp["source_annotations"]
        dne = candidate.get("nci_dne_class")
        dne_lof = candidate.get("nci_dne_lof_class")
        polymorphism = candidate.get("validated_polymorphism")
        if dne not in DNE:
            add_error(errors, cid, "nci_dne_class", "invalid or missing enum")
        if dne_lof not in DNE_LOF:
            add_error(errors, cid, "nci_dne_lof_class", "invalid or missing enum")
        if polymorphism not in POLYMORPHISM:
            add_error(errors, cid, "validated_polymorphism", "invalid or missing enum")
        if dne == ann["nci_dne_class"] and dne_lof == ann["nci_dne_lof_class"] and polymorphism == ann["validated_polymorphism"]:
            breakdown["source_annotations"] = 5
        else:
            add_error(errors, cid, "source_annotations", "NCI annotations must be reproduced exactly from the supplied evidence packet; do not infer them")

        supplied = candidate.get("evidence_ids")
        required = set(key["required_evidence_ids"])
        if isinstance(supplied, list) and all(isinstance(x, str) for x in supplied) and len(supplied) == len(set(supplied)) and required.issubset(set(supplied)) and set(supplied).issubset(known_source_ids):
            breakdown["evidence"] = 10
        else:
            add_error(errors, cid, "evidence_ids", f"must be unique known source IDs and include {sorted(required)}")

        if candidate.get("clinical_pathogenicity") == "not_assessed":
            breakdown["clinical_boundary"] = 5
        else:
            add_error(errors, cid, "clinical_pathogenicity", "must be 'not_assessed'")

        rationale = candidate.get("rationale")
        if isinstance(rationale, str) and len(rationale.strip()) >= 35 and all(source_id in rationale for source_id in required):
            breakdown["rationale_shape"] = 5
        else:
            add_error(errors, cid, "rationale", "must be at least 35 characters and cite each required evidence ID; semantic validity requires human review")

        confidence = candidate.get("confidence")
        if not isinstance(confidence, dict) or set(confidence) != {"assay", "overall"}:
            add_error(errors, cid, "confidence", "must contain exactly assay and overall fields")
        else:
            if confidence.get("assay") not in {"high_for_transcribed_panel_values", "moderate", "low", "indeterminate"}:
                add_error(errors, cid, "confidence.assay", "invalid or missing enum")
            if confidence.get("overall") not in {"provisional_requires_second_review", "moderate", "low", "indeterminate"}:
                add_error(errors, cid, "confidence.overall", "invalid or missing enum")

        per_case[cid] = breakdown
        points_earned += sum(breakdown.values())

    score = round(points_earned / points_possible * 100, 2)
    status = "PASS" if score == 100.0 and not errors and len(candidate_cases) == len(input_by) else "FAIL"
    return {
        "status": status,
        "score": score,
        "max_score": 100,
        "points_earned": points_earned,
        "points_possible": points_possible,
        "case_count_expected": len(input_by),
        "case_count_submitted": len(candidate_cases),
        "errors": errors,
        "score_breakdown_by_case": per_case,
        "interpretation": "Automated pass means structural and objective checks passed against a provisional reference key; it is not proof of biological truth or expert consensus. Free-text rationale semantics require human review."
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("submission", type=Path, help="Candidate JSON submission")
    parser.add_argument("--input", type=Path, default=INPUT)
    parser.add_argument("--key", type=Path, default=KEY)
    parser.add_argument("--report", type=Path, help="Optional report output path")
    args = parser.parse_args()
    try:
        report = verify(load(args.submission), load(args.input), load(args.key))
    except Exception as exc:
        report = {"status": "FAIL", "score": 0, "max_score": 100, "errors": [{"field": "runtime", "error": str(exc)}]}
    rendered = json.dumps(report, indent=2) + "\n"
    if args.report:
        args.report.write_text(rendered, encoding="utf-8")
    print(rendered, end="")
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
