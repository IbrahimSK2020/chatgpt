# Clinical TP53 Variant Functional Adjudication — v1.0.0 developer build

**Build status:** runnable developer benchmark package with Oracle, verifier, schemas, tests, source manifest, and a Claude enhancement brief. **Scientific status remains provisional**: this is not yet a qualified expert-panel gold-standard dataset.

## What this build does

This project asks an agent to adjudicate 11 TP53 functional-evidence cases using a supplied, versioned evidence packet. It separates:

1. **Primary assay classification** — recomputed from the median of eight Kato et al. yeast transactivation measurements.
2. **Overall functional phenotype** — a provisional case-level evidence judgment that can account for promoter heterogeneity, assay context, and possible splice confounding.
3. **Clinical pathogenicity** — explicitly out of scope; always report `not_assessed`.

The task-facing input omits the primary and overall labels. The developer bundle contains the provisional answer key under `oracle/` so that the build can be audited. **Do not expose `oracle/` or `oracle/reference_answers.json` to a task-solving agent in a scored evaluation.**

## Quick start (Python standard library only)

From this directory:

```bash
python oracle/oracle.py --output oracle/reference_submission.json
python verifier/verify.py docs/reference_submission_example.json --report validation/reference_verifier_report.json
python -m unittest discover -s tests -v
```

The reference submission is a demonstration of the output contract and should pass the automated verifier. A pass validates objective checks against the current provisional key; it does not certify scientific truth or human expert agreement.

## Files

- `data/task_input.json`: task-facing case packet, assay values, source annotations, evidence notes, and source registry; no gold labels.
- `data/promoter_activities.csv`: normalized eight-promoter source measurements.
- `data/source_manifest.csv`: upstream provenance and access dates.
- `data/source_reconciliation.csv`: page-level value reconciliation notes.
- `oracle/oracle.py`: deterministic reference-solution generator. Recomputes median and assay bins, then attaches frozen provisional overall adjudications.
- `oracle/reference_answers.json`: answer key, separate from task input.
- `verifier/verify.py`: independent checker and scoring report; independently recomputes medians, checks coverage/schema/objective labels/source IDs, and enforces the no-clinical-pathogenicity boundary.
- `tests/`: regression, mutation, data-integrity, and oracle/verifier tests.
- `schemas/`: JSON Schema contracts.
- `CLAUDE_ENHANCEMENT_PROMPT.md`: ready-to-paste instruction for Claude to audit and improve the project.
- `curation/`: criteria, case decisions, source reconciliation.
- `docs/human_review_rubric.md`: manual rubric for rationale and biological evidence review.

## Scientific thresholds

Per the NCI TP53 Database manual's Kato yeast assay description:

- median <= 20% WT: `functionally_abnormal`
- 20% WT < median <= 75% WT: `mixed_or_context_dependent`
- 75% WT < median <= 140% WT: `functionally_preserved`
- median > 140% WT: preserved function with a possible `supertrans` subclass; this pilot collapses that to `functionally_preserved` in its four-label schema.

All 11 cases in this pilot have complete panels, but missingness handling is tested in the calculation unit tests. Do not pool distinct assays or cell systems into the eight-promoter median.

## Current limitations that must remain visible

- The 11 variant panels were reconciled manually against official NCI variant-detail pages; the downloadable bulk R21 file was not checksummed and row-by-row compared in this session.
- The primary assay bins are deterministic given the transcribed values; overall labels are provisional and were not independently adjudicated by a second qualified human reviewer.
- The panel is small and hotspot-heavy; it is a pilot, not a broadly representative clinical genomics benchmark.
- Automated verifier checks cannot establish that free-text biological reasoning is semantically correct. Human review remains required.
- No clinical pathogenicity classification, diagnosis, or patient-specific medical recommendation is provided.

## Next release gates

1. Download the official R21 functional/structural data and systematic yeast assay files; record exact filenames, access date, byte count, SHA-256 checksums, and terms/attribution.
2. Reconcile all 88 values and variant identities against the bulk files, preserving any discrepancies instead of silently overwriting them.
3. Obtain independent qualified review of all overall phenotype labels; record reviewer disagreements and resolutions.
4. Expand with balanced non-hotspot and hard cases only after curation, including conflicting assay contexts, partial function, splice confounding, and DNE/LOF discordance.
5. Freeze a reviewed key; then run adversarial and mutation testing before using it for formal model evaluation.
