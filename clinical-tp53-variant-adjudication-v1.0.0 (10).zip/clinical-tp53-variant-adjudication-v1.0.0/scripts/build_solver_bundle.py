#!/usr/bin/env python3
"""Create a task-solver ZIP without answer key or gold-labelled files."""
from pathlib import Path
import zipfile, sys
ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT.parent/(ROOT.name+'-solver-only.zip')
include=[
 'README_solver.md','instruction.md','data/task_input.json','data/source_manifest.csv',
 'schemas/submission.schema.json','schemas/task_input.schema.json','docs/human_review_rubric.md'
]
# Create solver-specific README and blank schema-compatible output starter.
(ROOT/'README_solver.md').write_text("# TP53 Functional Adjudication — solver package\n\nUse `instruction.md` and `data/task_input.json`. The submission contract is `schemas/submission.schema.json`. No answer key is included. The task is research-only and does not assign clinical pathogenicity.\n",encoding='utf-8')
with zipfile.ZipFile(OUT,'w',zipfile.ZIP_DEFLATED) as z:
 for rel in include:
  p=ROOT/rel
  if p.exists(): z.write(p,arcname=rel)
print(OUT)
