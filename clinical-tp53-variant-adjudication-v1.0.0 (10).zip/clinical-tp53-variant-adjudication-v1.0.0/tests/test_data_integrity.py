import json, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
class DataIntegrityTests(unittest.TestCase):
 def test_unique_cases_and_complete_panels(self):
  d=json.loads((ROOT/'data/task_input.json').read_text())
  ids=[c['case_id'] for c in d['cases']]
  self.assertEqual(len(ids),11); self.assertEqual(len(set(ids)),11)
  expected=set(d['expected_promoters'])
  for c in d['cases']:
   m=c['primary_assay']['measurements_pct_wt']
   self.assertEqual(set(m),expected)
   self.assertTrue(all(isinstance(v,(int,float)) and v>=0 for v in m.values()))
 def test_task_input_has_no_gold_label_fields(self):
  d=json.loads((ROOT/'data/task_input.json').read_text())
  forbidden={'protein_assay_label','overall_functional_phenotype','reference_rationale','adjudication_rationale'}
  for c in d['cases']:
   self.assertFalse(forbidden.intersection(c.keys()))
 def test_source_ids_resolve(self):
  d=json.loads((ROOT/'data/task_input.json').read_text())
  known={x['source_id'] for x in d['source_registry']}
  for c in d['cases']:
   self.assertTrue(set(c['provenance']['source_ids']).issubset(known))
if __name__=='__main__': unittest.main()
