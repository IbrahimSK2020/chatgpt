import copy
import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'oracle'))
from oracle import build_reference, load_json, panel_label

class OracleTests(unittest.TestCase):
    def setUp(self):
        self.input_doc = load_json(ROOT / 'data/task_input.json')
        self.key_doc = load_json(ROOT / 'oracle/reference_answers.json')

    def test_reference_has_all_cases(self):
        out = build_reference(self.input_doc, self.key_doc)
        self.assertEqual(len(out['cases']), 11)
        self.assertEqual(len({x['case_id'] for x in out['cases']}), 11)

    def test_thresholds(self):
        self.assertEqual(panel_label(20), 'functionally_abnormal')
        self.assertEqual(panel_label(20.0001), 'mixed_or_context_dependent')
        self.assertEqual(panel_label(75), 'mixed_or_context_dependent')
        self.assertEqual(panel_label(75.0001), 'functionally_preserved')
        self.assertEqual(panel_label(140), 'functionally_preserved')
        self.assertEqual(panel_label(140.0001), 'functionally_preserved')
        self.assertEqual(panel_label(None), 'indeterminate')

    def test_duplicate_case_fails(self):
        d = copy.deepcopy(self.input_doc)
        d['cases'].append(copy.deepcopy(d['cases'][0]))
        with self.assertRaisesRegex(ValueError, 'Duplicate case_id'):
            build_reference(d, self.key_doc)

    def test_missing_promoter_fails(self):
        d = copy.deepcopy(self.input_doc)
        del d['cases'][0]['primary_assay']['measurements_pct_wt']['WAF1']
        with self.assertRaisesRegex(ValueError, 'expected exactly'):
            build_reference(d, self.key_doc)

    def test_negative_measurement_fails(self):
        d = copy.deepcopy(self.input_doc)
        d['cases'][0]['primary_assay']['measurements_pct_wt']['WAF1'] = -1
        with self.assertRaisesRegex(ValueError, 'negative'):
            build_reference(d, self.key_doc)

    def test_non_numeric_measurement_fails(self):
        d = copy.deepcopy(self.input_doc)
        d['cases'][0]['primary_assay']['measurements_pct_wt']['WAF1'] = 'not-a-number'
        with self.assertRaises(ValueError):
            build_reference(d, self.key_doc)

    def test_threshold_tampering_fails(self):
        d = copy.deepcopy(self.input_doc)
        d['thresholds']['functionally_abnormal']['median_lte_pct_wt'] = 19
        with self.assertRaisesRegex(ValueError, 'thresholds'):
            build_reference(d, self.key_doc)

    def test_case_order_does_not_change_per_case_result(self):
        a = build_reference(self.input_doc, self.key_doc)
        d = copy.deepcopy(self.input_doc)
        d['cases'].reverse()
        b = build_reference(d, self.key_doc)
        by_a = {c['case_id']: c for c in a['cases']}
        by_b = {c['case_id']: c for c in b['cases']}
        self.assertEqual(by_a, by_b)

    def test_two_oracle_runs_are_byte_identical(self):
        with tempfile.TemporaryDirectory() as td:
            p1 = Path(td) / 'a.json'
            p2 = Path(td) / 'b.json'
            for path in (p1, p2):
                subprocess.run([sys.executable, str(ROOT/'oracle/oracle.py'), '--output', str(path)], check=True, capture_output=True)
            self.assertEqual(p1.read_bytes(), p2.read_bytes())

if __name__ == '__main__':
    unittest.main()
