import copy, json, sys, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'verifier'))
from verify import verify, load
INPUT=load(ROOT/'data/task_input.json'); KEY=load(ROOT/'oracle/reference_answers.json')
REFERENCE=load(ROOT/'oracle/reference_submission.json')
class VerifierTests(unittest.TestCase):
 def test_reference_passes(self):
  self.assertEqual(verify(REFERENCE,INPUT,KEY)['status'],'PASS')
 def test_missing_case_fails(self):
  x=copy.deepcopy(REFERENCE); x['cases'].pop()
  self.assertEqual(verify(x,INPUT,KEY)['status'],'FAIL')
 def test_duplicate_case_fails(self):
  x=copy.deepcopy(REFERENCE); x['cases'].append(copy.deepcopy(x['cases'][0]))
  self.assertEqual(verify(x,INPUT,KEY)['status'],'FAIL')
 def test_wrong_median_fails(self):
  x=copy.deepcopy(REFERENCE); x['cases'][0]['median_pct_wt']+=2
  self.assertEqual(verify(x,INPUT,KEY)['status'],'FAIL')
 def test_wrong_label_fails(self):
  x=copy.deepcopy(REFERENCE); x['cases'][0]['protein_assay_label']='functionally_preserved'
  self.assertEqual(verify(x,INPUT,KEY)['status'],'FAIL')
 def test_wrong_overall_label_fails(self):
  x=copy.deepcopy(REFERENCE); x['cases'][0]['overall_functional_phenotype']='indeterminate'
  self.assertEqual(verify(x,INPUT,KEY)['status'],'FAIL')
 def test_missing_evidence_fails(self):
  x=copy.deepcopy(REFERENCE); x['cases'][0]['evidence_ids']=[]
  self.assertEqual(verify(x,INPUT,KEY)['status'],'FAIL')
 def test_unknown_evidence_fails(self):
  x=copy.deepcopy(REFERENCE); x['cases'][0]['evidence_ids'].append('SRC-FAKE')
  self.assertEqual(verify(x,INPUT,KEY)['status'],'FAIL')
 def test_clinical_pathogenicity_forbidden(self):
  x=copy.deepcopy(REFERENCE); x['clinical_pathogenicity']='pathogenic'
  self.assertEqual(verify(x,INPUT,KEY)['status'],'FAIL')
 def test_dne_mismatch_fails(self):
  x=copy.deepcopy(REFERENCE); x['cases'][0]['nci_dne_class']='No'
  self.assertEqual(verify(x,INPUT,KEY)['status'],'FAIL')
 def test_short_rationale_fails(self):
  x=copy.deepcopy(REFERENCE); x['cases'][0]['rationale']='Wrong'
  self.assertEqual(verify(x,INPUT,KEY)['status'],'FAIL')
 def test_unknown_case_fails(self):
  x=copy.deepcopy(REFERENCE); x['cases'][0]['case_id']='TP53-999'
  self.assertEqual(verify(x,INPUT,KEY)['status'],'FAIL')
 def test_missing_confidence_fails(self):
  x=copy.deepcopy(REFERENCE); del x['cases'][0]['confidence']
  self.assertEqual(verify(x,INPUT,KEY)['status'],'FAIL')
 def test_invalid_polymorphism_fails(self):
  x=copy.deepcopy(REFERENCE); x['cases'][0]['validated_polymorphism']='Maybe'
  self.assertEqual(verify(x,INPUT,KEY)['status'],'FAIL')
 def test_extra_case_field_fails(self):
  x=copy.deepcopy(REFERENCE); x['cases'][0]['clinical_diagnosis']='benign'
  self.assertEqual(verify(x,INPUT,KEY)['status'],'FAIL')
 def test_extra_top_level_field_fails(self):
  x=copy.deepcopy(REFERENCE); x['patient_diagnosis']='cancer'
  self.assertEqual(verify(x,INPUT,KEY)['status'],'FAIL')
if __name__=='__main__': unittest.main()
