# Changelog

## 1.0.0 — 2026-10-23

- Added deterministic Oracle and independent verifier.
- Added task-facing input packet with gold labels removed.
- Added provisional reference answer key and reference submission example for developer audit.
- Added JSON schemas, test suite, human review rubric, and Claude enhancement brief.
- Preserved source-page reconciliation and explicitly marked bulk-file audit and second-review gates as open.
- Added solver-only package builder to separate task inputs from answer key.
