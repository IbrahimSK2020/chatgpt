# Source reconciliation report — v0.1.1

**Audit date:** 2026-10-22  
**Authoritative source:** NCI TP53 Database R21 variant-detail pages, accessed via the official NCI TP53 website.  
**Manual thresholds reference:** https://tp53.cancer.gov/help (Kato assay bins documented in the NCI User Manual).

## Outcome

- 11 of 11 variant identities checked against their official NCI variant-detail pages.
- 11 of 11 cases now have all eight yeast transactivation values represented in the curated measurement table.
- 88 of 88 individual promoter values checked against the official variant-detail page displays.
- All medians recomputed from the 88 values; see `data/source_reconciliation.csv`.
- One wrong variant notation/source URL was corrected (p.R156C).
- One previously omitted full panel was added (p.V31I).
- The standardized yeast panel label and overall functional phenotype remain separate fields.

## Limits of this reconciliation

This release records a manual, case-by-case comparison against the official NCI variant-detail pages, not a checksum-level reconciliation against the downloadable bulk `FunctionIshiokaDownload_r21.csv` file. The bulk file was not captured in the current environment; its retrieval, checksum, and exact row-by-row comparison remain required before the data can be called fully source-file reconciled or expert-reviewed gold truth.

## Interpretation safeguards

- The eight-promoter median is an assay-specific result, not clinical pathogenicity.
- NCI's own user manual warns that other functional assays differ by constructs, response elements, cell systems, and experimental designs; results from distinct assay contexts are not pooled.
- DNE and DNE/LOF categories are retained as source annotations, not inferred from the transactivation median.
- The overall phenotype adjudication remains provisional and requires independent human review.
