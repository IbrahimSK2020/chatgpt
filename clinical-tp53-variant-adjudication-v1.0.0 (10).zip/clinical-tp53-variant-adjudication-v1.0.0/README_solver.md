# TP53 Functional Adjudication — solver package

Use `instruction.md` and `data/task_input.json`. The submission contract is `schemas/submission.schema.json`. No answer key is included. The task is research-only and does not assign clinical pathogenicity.
