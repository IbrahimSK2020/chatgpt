#!/usr/bin/env python3
"""Reference Oracle for the TP53 functional-adjudication pilot.

This is a reproducibility oracle, not a clinical decision-support tool. The eight-promoter
assay bin is computed from the supplied measurements. Overall phenotype labels are
provisional, frozen adjudication records and are explicitly marked as such.
"""
from __future__ import annotations
import argparse, json, statistics, sys, math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / "data" / "task_input.json"
KEY = ROOT / "oracle" / "reference_answers.json"
PROMOTERS = ["WAF1", "MDM2", "BAX", "H1433s", "AIP1", "GADD45", "NOXA", "P53R2"]
EXPECTED_THRESHOLDS = {
    "functionally_abnormal": {"median_lte_pct_wt": 20},
    "mixed_or_context_dependent": {"median_gt_pct_wt": 20, "median_lte_pct_wt": 75},
    "functionally_preserved": {"median_gt_pct_wt": 75, "median_lte_pct_wt": 140},
    "supertrans_subclass": {"median_gt_pct_wt": 140},
    "missing_panel": "indeterminate",
}

def panel_label(median):
    if median is None: return "indeterminate"
    if median <= 20: return "functionally_abnormal"
    if median <= 75: return "mixed_or_context_dependent"
    return "functionally_preserved"

def load_json(path):
    with path.open(encoding="utf-8") as f: return json.load(f)

def build_reference(input_doc, key_doc):
    if input_doc.get("thresholds") != EXPECTED_THRESHOLDS:
        raise ValueError("Task-input thresholds do not match the documented NCI Kato-assay bins")
    if key_doc.get("benchmark_version") != input_doc.get("benchmark_version"):
        raise ValueError("Input and answer key benchmark versions differ")
    key_by_id = {c["case_id"]: c for c in key_doc["cases"]}
    if len(key_by_id) != len(key_doc["cases"]):
        raise ValueError("Duplicate case_id in answer key")
    out=[]
    seen=set()
    for case in input_doc["cases"]:
        cid=case["case_id"]
        if cid in seen: raise ValueError(f"Duplicate case_id in input: {cid}")
        seen.add(cid)
        measurements=case["primary_assay"]["measurements_pct_wt"]
        if set(measurements) != set(PROMOTERS):
            raise ValueError(f"{cid}: expected exactly {PROMOTERS}, got {sorted(measurements)}")
        vals=[float(measurements[p]) for p in PROMOTERS]
        if any(not math.isfinite(v) for v in vals): raise ValueError(f"{cid}: non-finite activity value")
        if any(v < 0 for v in vals): raise ValueError(f"{cid}: negative activity value")
        med=statistics.median(vals)
        key=key_by_id.get(cid)
        if key is None: raise ValueError(f"No adjudication key for {cid}")
        # Detect stale or mismatched key; do not silently trust stored medians.
        if abs(float(key["median_pct_wt"]) - med) > 1e-6:
            raise ValueError(f"{cid}: key median disagrees with supplied values")
        computed_label=panel_label(med)
        if computed_label != key["protein_assay_label"]:
            raise ValueError(f"{cid}: key assay label disagrees with threshold rule")
        ann=case["source_annotations"]
        ev_ids=key["required_evidence_ids"]
        out.append({
            "case_id":cid,
            "median_pct_wt":round(med, 6),
            "protein_assay_label":computed_label,
            "overall_functional_phenotype":key["overall_functional_phenotype"],
            "nci_dne_class":ann["nci_dne_class"],
            "nci_dne_lof_class":ann["nci_dne_lof_class"],
            "validated_polymorphism":ann["validated_polymorphism"],
            "clinical_pathogenicity":"not_assessed",
            "evidence_ids":ev_ids,
            "rationale":key["reference_rationale"] + " Evidence: " + ", ".join(ev_ids),
            "confidence":{
                "assay":"high_for_transcribed_panel_values",
                "overall":"provisional_requires_second_review"
            }
        })
    if set(key_by_id) != seen:
        missing=sorted(set(key_by_id)-seen)
        extra=sorted(seen-set(key_by_id))
        raise ValueError(f"Input/key case mismatch; missing={missing}, extra={extra}")
    return {
        "benchmark_id":input_doc["benchmark_id"],
        "benchmark_version":input_doc["benchmark_version"],
        "status":"provisional_curated_pilot_not_expert_panel_gold_standard",
        "clinical_pathogenicity":"not_assessed",
        "cases":out
    }

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", type=Path, default=INPUT)
    parser.add_argument("--key", type=Path, default=KEY)
    parser.add_argument("--output", type=Path, help="Output JSON path; default stdout")
    args=parser.parse_args()
    try:
        result=build_reference(load_json(args.input), load_json(args.key))
    except Exception as e:
        print(f"ORACLE_ERROR: {e}", file=sys.stderr); return 2
    rendered=json.dumps(result, indent=2)+"\n"
    if args.output:
        args.output.write_text(rendered, encoding="utf-8")
        print(f"Wrote {len(result['cases'])} reference cases to {args.output}")
    else: print(rendered, end="")
    return 0

if __name__ == "__main__": raise SystemExit(main())
