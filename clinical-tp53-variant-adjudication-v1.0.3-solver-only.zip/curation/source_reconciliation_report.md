# Official NCI variant-page reconciliation — v1.0.3

**Comparison date:** 2026-10-23
**Upstream dataset:** NCI TP53 Database R21 (January 2025); website version 1.1.4 was displayed during this review.
**Primary source:** official NCI TP53 variant-detail pages linked row-by-row in `data/nci_variant_page_measurements.csv`.

## Results

- 11/11 variant identities matched the official NCI detail-page heading and cDNA/protein identity.
- 88/88 promoter measurements were transcribed from the eight yeast columns on the official variant-detail pages and compared against the curated task packet.
- 88 exact matches; 0 numeric discrepancies; 0 missing or duplicate case/promoter pairs.
- Values above 100% WT were retained as displayed. Human-cell (Saos-2) measurements were not included in the yeast median.
- `scripts/reconcile_nci_variant_pages.py` independently reads the snapshot and task JSON, enforces complete one-to-one coverage, validates source type and numeric values, and flags mismatches without replacement.

## Scope and limitations

This is **page-level source reconciliation using manually transcribed official NCI web-page displays**. The rendered HTML bytes were not archived and the official `FunctionIshiokaDownload_r21.csv` bulk file was not acquired in this environment. Consequently no official bulk-file filename/byte-size/SHA-256/source-row key is available, and checksum-level bulk reconciliation remains open. The snapshot is real source-derived data, not synthetic biological data; its provenance limitation must remain explicit.

The source pages include NCI annotations such as transactivation class, DNE, DNE/LOF, hotspot, structural motif, splice predictions, and other assay summaries. These are preserved as attributed source annotations, not treated as a substitute for independent overall-phenotype adjudication. In particular, p.G187S has a source-page splice-donor-site concern; p.P72R and p.V31I are annotated as validated polymorphisms; and p.V31I's overall functional interpretation still warrants expert review.

## Sources

- [NCI TP53 Database R21 / About](https://tp53.cancer.gov/about)
- [NCI TP53 Database user manual](https://tp53.cancer.gov/help)
- [NCI dataset downloads](https://tp53.cancer.gov/get_tp53data)
- [Kato et al. 2003, PMID 12826609](https://pubmed.ncbi.nlm.nih.gov/12826609/)

Do not describe this as bulk-file reconciliation or expert-reviewed gold truth.
