# Sources and provenance

All access dates in this pilot: **2026-10-22**.

1. NCI TP53 Database, About and R21 release information: https://tp53.cancer.gov/about
2. NCI TP53 Database User Manual, including Kato transactivation thresholds and caution on assay comparability: https://tp53.cancer.gov/help
3. NCI TP53 Database downloads page: https://tp53.cancer.gov/get_tp53data
4. Kato et al. 2003, PMID 12826609: https://pubmed.ncbi.nlm.nih.gov/12826609/
5. Selected variant-detail records are listed individually in `data/source_manifest.csv`. These pages are the source for the displayed eight-promoter values and NCI annotations.
6. ClinVar VCV000127827 (p.Val31Ile) is used only for secondary functional evidence context: https://www.ncbi.nlm.nih.gov/clinvar/variation/127827/

## Version semantics

- **Upstream release:** NCI TP53 Database R21, documented as January 2025.
- **Upstream web app:** version 1.1.4, last updated 2026-05-29 on the accessed NCI pages.
- **Curated slice version:** 0.1.0, frozen 2026-10-22.
- **No full upstream CSV is bundled.** This pilot contains a small set of selected measurements transcribed from the variant detail pages. The source manifest and per-row URLs provide provenance. A case-by-case comparison against the official NCI variant-detail pages is recorded in `curation/source_reconciliation_report.md`. The bulk R21 CSV has not yet been captured/checksummed, so bulk-file reconciliation remains outstanding before expert gold-standard release.


## Independent source check performed for this revision (2026-10-23)
- NCI TP53 Database About page confirms the current database release is R21 (Jan 2025) and identifies NCI stewardship: https://tp53.cancer.gov/about
- NCI download page lists the functional/structural and systematic yeast assay datasets: https://tp53.cancer.gov/get_tp53data
- NCI user manual describes `FunctionIshiokaDownload_r21.csv` and states it contains promoter-specific yeast measurements as percent of wild-type activity; it also distinguishes separate Saos-2 measurements: https://tp53.cancer.gov/help
- These official pages were checked through web search in this revision. The downloadable file bytes were **not** acquired into the project workspace, so there is no bulk-file checksum or row-level reconciliation. This source check verifies release metadata and dataset descriptions only, not the exact 88 values.


## Additional source verification (2026-10-23)
- NCI TP53 Database About page identifies the current database release as R21 (January 2025): https://tp53.cancer.gov/about
- NCI dataset download page lists the systematic yeast assay dataset: https://tp53.cancer.gov/get_tp53data
- NCI user manual names `FunctionIshiokaDownload_r21.csv` and states its eight promoter-specific yeast activities are percent of WT; it separately describes human Saos-2 measurements: https://tp53.cancer.gov/help
- The NCI manual defines median <=20 as non-functional, >20 to <=75 partially functional, >75 to <=140 functional, and >140 as supertrans. The benchmark now retains `supertrans` as a distinct standardized assay class; overall phenotype remains a separate evidence adjudication.
- These web documentation checks do not substitute for acquiring the bulk file. This execution environment could not resolve `tp53.cancer.gov` from the container (`NameResolutionError`), so the source file bytes were not retrieved, hashed, or reconciled.


## v1.0.3 page-level snapshot

The eight yeast promoter measurements per case were rechecked against the official NCI TP53 variant-detail page displays on 2026-10-23. `data/nci_variant_page_measurements.csv` records each official page URL and each transcribed value; `validation/variant_page_reconciliation.csv` records the comparison against task input. The result was 88/88 exact matches. This is a manually transcribed page-display snapshot, not raw HTML archival or checksum-level reconciliation against the downloadable bulk file.
