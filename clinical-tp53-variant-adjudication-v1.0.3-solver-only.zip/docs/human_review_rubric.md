# Human review rubric for overall functional phenotype

This rubric is for a qualified independent reviewer. Review the supplied raw evidence without seeing the current overall label or rationale first. The primary yeast panel class is computed mechanically (`supertrans` is distinct for median >140% WT) and should not be used as a proxy for clinical pathogenicity.

## Required review fields per case

- Reviewer ID/qualification and review date.
- Confirmed variant identity and transcript/cDNA/protein notation.
- Confirmation of all eight promoter values against the cited source.
- Independent median and primary assay bin.
- Assay model, endpoint, and limitations.
- Whether there is credible evidence for partial function, promoter-specific effects, splice alteration, or conflict among distinct assay systems.
- Overall phenotype: `functionally_abnormal`, `functionally_preserved`, `mixed_or_context_dependent`, or `indeterminate`.
- Confidence and evidence supporting/limiting the conclusion.
- Whether the previous adjudication agrees, disagrees, or cannot be resolved.
- Written reason for any proposed change; no forced consensus.

## Label guidance

- `functionally_abnormal`: evidence consistently supports substantially impaired function in the specified functional context.
- `functionally_preserved`: evidence supports retained function in the evaluated contexts, with no major unresolved confound in the evidence packet.
- `mixed_or_context_dependent`: partial residual activity, promoter-specific heterogeneity, or meaningful assay-context differences prevent a simple global label.
- `indeterminate`: missing, conflicting, or confounded evidence prevents a defensible overall functional conclusion.

## Prohibited shortcuts

Do not use cancer hotspot status, tumor recurrence, an in-silico score, or a clinical database classification as a substitute for functional evidence. Do not infer gain-of-function from loss of function or DNE. Do not infer clinical pathogenicity from this functional benchmark.

## Reviewer decision sheet template

| Case ID | Variant identity confirmed? | 8 values checked? | Independent median | Primary assay label | Overall label | Confidence | Agree/disagree/unresolved | Evidence IDs | Rationale |
|---|---|---|---:|---|---|---|---|---|---|


## Blinded independent review worksheet protocol
Reviewers must not see the existing overall label, rationale, or key while making an initial decision. For each case record: reviewer ID/code; date; relevant variant identity; assay context and eight promoter values; source IDs and direct-versus-inferred evidence; splice/context caveats; initial overall label; confidence (high/moderate/low); concise rationale; missing evidence; and whether a second reviewer is required. After both reviews are locked, unblind and record agreement, each disagreement, resolution rationale, adjudicator, date, and whether the label remains indeterminate. Do not describe review as independent or completed until signed records exist.

## Review safety
This worksheet supports research adjudication only. It must not elicit clinical pathogenicity labels. A high assay confidence refers only to arithmetic over transcribed values, not source authenticity or clinical validity.


## v1.0.3 independent review requirements

- Use the separate `review/reviewer_A_initial_review.csv` and `review/reviewer_B_initial_review.csv` files; do not exchange decisions before both are locked.
- Reviewers should document TP53 functional-assay / molecular oncology / cancer-genetics qualifications and conflicts of interest. Use a third qualified adjudicator for material disagreements.
- Use `review/source_context_evidence.csv` as source-attributed context. NCI database annotations are not the benchmark's gold label and must not be copied uncritically.
- Preserve each initial decision and rationale. Unresolved disagreements must remain explicit; do not force consensus.
- The developer-only mapping is `curation/reviewer_blind_key.csv`; do not distribute it to reviewers until both initial reviews are locked.
- No independent review is complete until reviewer-authored decisions, qualifications, dates, evidence citations, and disagreement outcomes have been returned and audited.
