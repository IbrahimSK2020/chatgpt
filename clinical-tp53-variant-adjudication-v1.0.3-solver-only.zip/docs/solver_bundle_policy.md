# Solver-only bundle policy

A scored task-solver package must include `instruction.md`, `data/task_input.json`, `schemas/submission.schema.json`, relevant source notes, and a blank output template. It must **exclude** `oracle/`, the answer key, reference submission, gold labels, and adjudication decision log. The developer bundle may include those files for engineering and audit.

Use `scripts/build_solver_bundle.py` to generate a ZIP that excludes the answer key and gold-labelled curation files. Inspect the archive contents before release; do not assume the script is a security boundary.
