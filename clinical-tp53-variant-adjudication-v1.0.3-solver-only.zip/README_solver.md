# TP53 Functional Adjudication — solver package

Research/evaluation benchmark only; not for diagnosis or treatment. Follow `instruction.md`; use `data/task_input.json` and the schemas. The task contains 11 curated cases and 88 yeast promoter measurements. The 88 measurements match the official NCI variant-detail page displays in the page-level reconciliation snapshot. The official bulk file has not been checksummed or row-reconciled; overall phenotype labels remain provisional and not expert-panel gold truth.

## Run
No third-party dependencies are required for ordinary JSON authoring. A solver should return one JSON object conforming to `schemas/submission.schema.json`. Clinical pathogenicity must be `not_assessed`. See `sources.md` for attribution and source limitations.
