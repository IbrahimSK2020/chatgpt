# Task instructions — Clinical TP53 Variant Functional Adjudication

You are given a fixed evidence packet for 11 TP53 variants. Use only the supplied packet and its stated source annotations for this benchmark. Your job is to adjudicate functional evidence, not to make a clinical diagnosis.

For each case:

1. Calculate the median of the eight listed yeast transactivation activities (WAF1, MDM2, BAX, H1433s, AIP1, GADD45, NOXA, P53R2), each expressed as percent of wild-type activity.
2. Assign the assay-specific label using the thresholds in the packet: <=20% = `functionally_abnormal`; >20% and <=75% = `mixed_or_context_dependent`; >75% and <=140% = `functionally_preserved`; >140% = `supertrans` (a distinct assay classification; overall phenotype remains separately adjudicated).
3. Separately assign the overall functional phenotype using all supplied evidence. Account for promoter-specific variation, assay context, missingness, and possible splice confounding. Do not let a protein-only assay erase evidence that the genomic variant may affect splicing.
4. Report the NCI DNE and DNE/LOF annotations as source annotations. Do not infer DNE, LOF, or gain-of-function from the transactivation median, cancer hotspot status, or a prediction score alone.
5. Include source evidence IDs for the assay method, variant-specific evidence, and any additional evidence needed for that case. Keep rationales concise and evidence-linked.
6. Set `clinical_pathogenicity` to `not_assessed` for the entire submission and every case. Do not infer ACMG/AMP pathogenicity or diagnose a patient.
7. Return exactly one case object per supplied `case_id`, in the schema described in `schemas/submission.schema.json`. Do not add or omit cases. Missing values must remain missing; do not invent data.

The dataset and overall adjudication labels are a provisional research pilot. Do not represent them as expert-panel gold truth.

You have 28800 seconds to complete the analysis. Do not use online solutions or task-specific external hints.
